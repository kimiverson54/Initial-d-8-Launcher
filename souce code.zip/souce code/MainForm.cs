using System.Diagnostics;
using System.Text.Json;

namespace InitialD8Launcher;

public sealed class MainForm : Form
{
    private const string LoaderRelativePath = @"OpenParrotWin32\OpenParrotLoader.exe";
    private const string CoreRelativePath = "TeknoParrot.dll";
    private const string RomRelativePath = "rom";

    private readonly TextBox _loaderBox = new();
    private readonly TextBox _coreBox = new();
    private readonly TextBox _romBox = new();
    private readonly ComboBox _gameBox = new();
    private readonly Label _loaderStatus = new();
    private readonly Label _coreStatus = new();
    private readonly Label _gameStatus = new();
    private readonly Label _overallStatus = new();
    private readonly Button _launchButton = new();
    private readonly Button _testModeButton = new();
    private readonly CheckBox _showLoaderWindow = new();
    private readonly CheckBox _enableCardReader = new();
    private readonly NumericUpDown _resolutionWidthBox = new();
    private readonly NumericUpDown _resolutionHeightBox = new();
    private readonly ComboBox _windowModeBox = new();
    private readonly ComboBox _resolutionModeBox = new();
    private readonly ComboBox _renderResolutionBox = new();
    private readonly CheckBox _linearFilteringBox = new();
    private readonly CheckBox _framelimiterBox = new();
    private readonly ComboBox _gpuFixBox = new();
    private readonly Button _resetSettingsButton = new();
    private readonly Button _inputSettingsButton = new();
    private readonly InputListener _inputListener = new();
    private Id8Config _currentGraphicsConfig = Id8Config.CreateDefault();

    private string BaseDir => AppContext.BaseDirectory;
    private string DefaultLoaderPath => ResolveRelativePath(LoaderRelativePath);
    private string LoaderPath => ResolveLoaderPath();
    private string DefaultCorePath => ResolveRelativePath(CoreRelativePath);
    private string DefaultRomPath => ResolveRelativePath(RomRelativePath);
    private string ConfigDir => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "InitialD8Launcher");
    private string ConfigPath => Path.Combine(ConfigDir, "config.json");

    private IEnumerable<string> GetSearchRoots()
    {
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        foreach (var root in new[] { BaseDir, Directory.GetCurrentDirectory() })
        {
            if (!string.IsNullOrWhiteSpace(root) && seen.Add(root))
                yield return root;
        }

        var current = new DirectoryInfo(BaseDir);
        for (var i = 0; i < 6 && current is not null; i++)
        {
            current = current.Parent;
            if (current is null)
                break;

            if (seen.Add(current.FullName))
                yield return current.FullName;
        }
    }

    private string? FindFirstExistingFile(params string[] candidates)
    {
        foreach (var root in GetSearchRoots())
        {
            foreach (var candidate in candidates)
            {
                var fullPath = Path.IsPathRooted(candidate)
                    ? candidate
                    : Path.GetFullPath(Path.Combine(root, candidate));

                if (File.Exists(fullPath))
                    return fullPath;
            }
        }

        return null;
    }

    private string? FindFirstExistingDirectory(params string[] candidates)
    {
        foreach (var root in GetSearchRoots())
        {
            foreach (var candidate in candidates)
            {
                var fullPath = Path.IsPathRooted(candidate)
                    ? candidate
                    : Path.GetFullPath(Path.Combine(root, candidate));

                if (Directory.Exists(fullPath))
                    return fullPath;
            }
        }

        return null;
    }

    private string ResolveLoaderPath()
    {
        return ResolveConfiguredPath(_loaderBox.Text, LoaderRelativePath);
    }

    private string ResolveCorePath()
    {
        return ResolveConfiguredPath(_coreBox.Text, CoreRelativePath);
    }

    private string ResolveRomPath()
    {
        return ResolveConfiguredPath(_romBox.Text, RomRelativePath);
    }

    private string ResolveConfiguredPath(string? configuredValue, string fallbackRelativePath)
    {
        if (string.IsNullOrWhiteSpace(configuredValue))
            return ResolveRelativePath(fallbackRelativePath);

        var trimmed = configuredValue.Trim();
        return Path.IsPathRooted(trimmed)
            ? trimmed
            : Path.GetFullPath(Path.Combine(BaseDir, trimmed));
    }

    private string ResolveRelativePath(string relativePath)
    {
        return Path.GetFullPath(Path.Combine(BaseDir, relativePath));
    }

    public MainForm()
    {
        Text = "Initial D 8 Launcher";
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(820, 620);
        ClientSize = new Size(880, 760);
        Font = new Font("Segoe UI", 10F);

        BuildUi();
        InputManager.Instance.Load();
        _inputListener.Start();
        FormClosed += (_, _) =>
        {
            SaveConfig();
            _inputListener.Stop();
        };
        LoadConfig();
        NormalizePaths();
        RefreshGameList();
        LoadSelectedGameSettings();
        UpdateStatus();
    }

    private void BuildUi()
    {
        BackColor = Color.FromArgb(12, 14, 18);
        ClientSize = new Size(1080, 710);
        MinimumSize = new Size(980, 650);
        Padding = new Padding(18);
        AutoScaleMode = AutoScaleMode.Dpi;

        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 3,
            BackColor = Color.FromArgb(12, 14, 18),
            Padding = new Padding(0),
            Margin = new Padding(0)
        };
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 96F));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 58F));

        var header = new Panel
        {
            Dock = DockStyle.Fill,
            BackColor = Color.FromArgb(15, 17, 22),
            Padding = new Padding(26, 18, 22, 12)
        };

        var title = new Label
        {
            Text = "INITIAL D 8",
            AutoSize = true,
            Font = new Font("Segoe UI", 26F, FontStyle.Bold),
            ForeColor = Color.FromArgb(245, 246, 247),
            Location = new Point(0, 8)
        };

        var subtitle = new Label
        {
            Text = "INFINITY",
            AutoSize = true,
            ForeColor = Color.FromArgb(200, 204, 214),
            Font = new Font("Segoe UI", 9F, FontStyle.Bold),
            Location = new Point(0, 56)
        };

        var statusChip = new Label
        {
            Text = "GAME DETECTED",
            AutoSize = true,
            ForeColor = Color.FromArgb(255, 90, 90),
            BackColor = Color.FromArgb(28, 20, 22),
            BorderStyle = BorderStyle.FixedSingle,
            Padding = new Padding(10, 4, 10, 4),
            Font = new Font("Segoe UI", 8.5F, FontStyle.Bold),
            Anchor = AnchorStyles.Top | AnchorStyles.Right
        };
        statusChip.Location = new Point(header.Width - statusChip.Width - 12, 22);

        header.Controls.Add(title);
        header.Controls.Add(subtitle);
        header.Controls.Add(statusChip);

        var content = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 1,
            BackColor = Color.FromArgb(12, 14, 18),
            Padding = new Padding(0),
            Margin = new Padding(0)
        };
        content.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 42F));
        content.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 58F));

        var leftPanel = new Panel
        {
            Dock = DockStyle.Fill,
            BackColor = Color.FromArgb(17, 20, 25),
            Padding = new Padding(18)
        };

        var leftTable = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 5,
            BackColor = Color.FromArgb(17, 20, 25),
            Padding = new Padding(0),
            Margin = new Padding(0)
        };
        leftTable.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        leftTable.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        leftTable.RowStyles.Add(new RowStyle(SizeType.Absolute, 36F));
        leftTable.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        leftTable.RowStyles.Add(new RowStyle(SizeType.AutoSize));

        var leftTitle = new Label
        {
            Text = "Initial D 8",
            AutoSize = true,
            Font = new Font("Segoe UI", 24F, FontStyle.Bold),
            ForeColor = Color.FromArgb(247, 248, 250),
            Margin = new Padding(0, 0, 0, 6)
        };

        var exeCaption = new Label
        {
            Text = "Current EXE",
            AutoSize = true,
            ForeColor = Color.FromArgb(173, 183, 194),
            Font = new Font("Segoe UI", 9F, FontStyle.Bold),
            Margin = new Padding(0, 0, 0, 6)
        };

        _gameBox.Anchor = AnchorStyles.Left | AnchorStyles.Right;
        _gameBox.DropDownStyle = ComboBoxStyle.DropDownList;
        _gameBox.FlatStyle = FlatStyle.Flat;
        _gameBox.BackColor = Color.FromArgb(25, 30, 37);
        _gameBox.ForeColor = Color.FromArgb(240, 242, 245);
        _gameBox.Font = new Font("Segoe UI", 10F);
        _gameBox.SelectedIndexChanged += (_, _) =>
        {
            LoadSelectedGameSettings();
            UpdateStatus();
        };

        _gameStatus.AutoSize = true;
        _gameStatus.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        _gameStatus.ForeColor = Color.FromArgb(127, 228, 150);
        _gameStatus.Margin = new Padding(0, 12, 0, 0);

        var actionRow = new FlowLayoutPanel
        {
            Dock = DockStyle.Top,
            AutoSize = false,
            Height = 94,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = true,
            Margin = new Padding(0, 14, 0, 0),
            Padding = new Padding(0)
        };

        _launchButton.Text = "LAUNCH GAME";
        _launchButton.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
        _launchButton.Width = 188;
        _launchButton.Height = 42;
        _launchButton.BackColor = Color.FromArgb(214, 44, 44);
        _launchButton.ForeColor = Color.White;
        _launchButton.FlatStyle = FlatStyle.Flat;
        _launchButton.FlatAppearance.BorderSize = 0;
        _launchButton.Click += (_, _) => LaunchGame(false);

        _testModeButton.Text = "TEST MODE";
        _testModeButton.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        _testModeButton.Width = 132;
        _testModeButton.Height = 42;
        _testModeButton.BackColor = Color.FromArgb(52, 58, 68);
        _testModeButton.ForeColor = Color.FromArgb(245, 246, 247);
        _testModeButton.FlatStyle = FlatStyle.Flat;
        _testModeButton.Margin = new Padding(10, 0, 0, 0);
        _testModeButton.FlatAppearance.BorderSize = 0;
        _testModeButton.Click += (_, _) => LaunchGame(true);

        var openFolderButton = new Button
        {
            Text = "OPEN GAME FOLDER",
            Font = new Font("Segoe UI", 10F, FontStyle.Bold),
            Width = 154,
            Height = 42,
            BackColor = Color.FromArgb(39, 46, 56),
            ForeColor = Color.FromArgb(234, 236, 239),
            FlatStyle = FlatStyle.Flat,
            Margin = new Padding(14, 0, 0, 0)
        };
        openFolderButton.FlatAppearance.BorderSize = 0;
        openFolderButton.Click += (_, _) =>
        {
            var romDirectory = ResolveRomPath();
            if (Directory.Exists(romDirectory))
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = romDirectory,
                    UseShellExecute = true
                });
            }
        };

        actionRow.Controls.Add(_launchButton);
        actionRow.Controls.Add(_testModeButton);
        actionRow.Controls.Add(openFolderButton);

        leftTable.Controls.Add(leftTitle, 0, 0);
        leftTable.Controls.Add(exeCaption, 0, 1);
        leftTable.Controls.Add(_gameBox, 0, 2);
        leftTable.Controls.Add(_gameStatus, 0, 3);
        leftTable.Controls.Add(actionRow, 0, 4);

        leftPanel.Controls.Add(leftTable);

        var rightPanel = new Panel
        {
            Dock = DockStyle.Fill,
            BackColor = Color.FromArgb(17, 20, 25),
            Padding = new Padding(18)
        };

        var graphicsTable = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 9,
            BackColor = Color.FromArgb(17, 20, 25),
            Padding = new Padding(0),
            Margin = new Padding(0)
        };
        graphicsTable.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 38F));
        graphicsTable.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 62F));

        var graphicsTitle = new Label
        {
            Text = "Graphics",
            AutoSize = true,
            Font = new Font("Segoe UI", 20F, FontStyle.Bold),
            ForeColor = Color.FromArgb(245, 248, 250),
            Margin = new Padding(0, 0, 0, 14)
        };

        graphicsTable.Controls.Add(graphicsTitle, 0, 0);
        graphicsTable.SetColumnSpan(graphicsTitle, 2);

        AddSettingRow(graphicsTable, 1, "Resolution Width", _resolutionWidthBox);
        AddSettingRow(graphicsTable, 2, "Resolution Height", _resolutionHeightBox);
        AddSettingRow(graphicsTable, 3, "Windowed", _windowModeBox);
        AddSettingRow(graphicsTable, 4, "Resolution Mode", _resolutionModeBox);
        AddSettingRow(graphicsTable, 5, "Render Resolution", _renderResolutionBox);
        AddSettingRow(graphicsTable, 6, "Linear Filtering", _linearFilteringBox);
        AddSettingRow(graphicsTable, 7, "Framelimiter", _framelimiterBox);
        AddSettingRow(graphicsTable, 8, "GPU Fix", _gpuFixBox);

        _resolutionWidthBox.Minimum = 640;
        _resolutionWidthBox.Maximum = 3840;
        _resolutionWidthBox.Value = 1360;
        _resolutionWidthBox.Width = 170;
        _resolutionWidthBox.BackColor = Color.FromArgb(25, 30, 37);
        _resolutionWidthBox.ForeColor = Color.FromArgb(238, 242, 246);
        _resolutionWidthBox.BorderStyle = BorderStyle.FixedSingle;

        _resolutionHeightBox.Minimum = 480;
        _resolutionHeightBox.Maximum = 2160;
        _resolutionHeightBox.Value = 768;
        _resolutionHeightBox.Width = 170;
        _resolutionHeightBox.BackColor = Color.FromArgb(25, 30, 37);
        _resolutionHeightBox.ForeColor = Color.FromArgb(238, 242, 246);
        _resolutionHeightBox.BorderStyle = BorderStyle.FixedSingle;

        _windowModeBox.Items.Clear();
        _windowModeBox.Items.AddRange(new object[] { "Windowed", "Fullscreen" });
        _windowModeBox.SelectedIndex = 0;
        _windowModeBox.DropDownStyle = ComboBoxStyle.DropDownList;
        _windowModeBox.BackColor = Color.FromArgb(25, 30, 37);
        _windowModeBox.ForeColor = Color.FromArgb(238, 242, 246);
        _windowModeBox.FlatStyle = FlatStyle.Flat;

        _resolutionModeBox.Items.Clear();
        _resolutionModeBox.Items.AddRange(new object[] { "Upscale", "Game" });
        _resolutionModeBox.SelectedIndex = 0;
        _resolutionModeBox.DropDownStyle = ComboBoxStyle.DropDownList;
        _resolutionModeBox.BackColor = Color.FromArgb(25, 30, 37);
        _resolutionModeBox.ForeColor = Color.FromArgb(238, 242, 246);
        _resolutionModeBox.FlatStyle = FlatStyle.Flat;

        _renderResolutionBox.Items.Clear();
        _renderResolutionBox.Items.AddRange(new object[] { "Auto", "Stock", "1.5x", "2x" });
        _renderResolutionBox.SelectedIndex = 0;
        _renderResolutionBox.DropDownStyle = ComboBoxStyle.DropDownList;
        _renderResolutionBox.BackColor = Color.FromArgb(25, 30, 37);
        _renderResolutionBox.ForeColor = Color.FromArgb(238, 242, 246);
        _renderResolutionBox.FlatStyle = FlatStyle.Flat;

        _linearFilteringBox.Text = "Linear Filtering";
        _linearFilteringBox.Checked = true;
        _linearFilteringBox.ForeColor = Color.FromArgb(238, 242, 246);
        _linearFilteringBox.BackColor = Color.Transparent;

        _framelimiterBox.Text = "Framelimiter";
        _framelimiterBox.Checked = true;
        _framelimiterBox.ForeColor = Color.FromArgb(238, 242, 246);
        _framelimiterBox.BackColor = Color.Transparent;

        _gpuFixBox.Items.Clear();
        _gpuFixBox.Items.AddRange(new object[] { "None", "AMD", "New AMD Driver", "INTEL" });
        _gpuFixBox.SelectedIndex = 0;
        _gpuFixBox.DropDownStyle = ComboBoxStyle.DropDownList;
        _gpuFixBox.BackColor = Color.FromArgb(25, 30, 37);
        _gpuFixBox.ForeColor = Color.FromArgb(238, 242, 246);
        _gpuFixBox.FlatStyle = FlatStyle.Flat;

        _inputSettingsButton.Text = "INPUT SETTINGS";
        _inputSettingsButton.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
        _inputSettingsButton.Height = 36;
        _inputSettingsButton.Width = 170;
        _inputSettingsButton.BackColor = Color.FromArgb(39, 46, 56);
        _inputSettingsButton.ForeColor = Color.FromArgb(238, 242, 246);
        _inputSettingsButton.FlatStyle = FlatStyle.Flat;
        _inputSettingsButton.FlatAppearance.BorderSize = 0;
        _inputSettingsButton.Margin = new Padding(0, 10, 0, 0);
        _inputSettingsButton.Click += (_, _) =>
        {
            using var form = new InputSettingsForm();
            form.ShowDialog(this);
        };

        _enableCardReader.Text = "Enable ID8 card reader";
        _enableCardReader.AutoSize = true;
        _enableCardReader.Checked = true;
        _enableCardReader.ForeColor = Color.FromArgb(200, 206, 214);
        _enableCardReader.BackColor = Color.Transparent;
        _enableCardReader.Margin = new Padding(0, 10, 18, 0);
        _enableCardReader.CheckedChanged += (_, _) => SaveConfig();

        _showLoaderWindow.Text = "Show OpenParrotLoader window (debug)";
        _showLoaderWindow.AutoSize = true;
        _showLoaderWindow.Checked = false;
        _showLoaderWindow.ForeColor = Color.FromArgb(200, 206, 214);
        _showLoaderWindow.BackColor = Color.Transparent;
        _showLoaderWindow.Margin = new Padding(0, 10, 18, 0);
        _showLoaderWindow.CheckedChanged += (_, _) => SaveConfig();

        var statusBar = new Panel
        {
            Dock = DockStyle.Fill,
            BackColor = Color.FromArgb(15, 17, 22),
            Padding = new Padding(18, 8, 18, 8),
            BorderStyle = BorderStyle.None
        };

        _overallStatus.Anchor = AnchorStyles.Left | AnchorStyles.Top;
        _overallStatus.AutoSize = true;
        _overallStatus.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        _overallStatus.ForeColor = Color.FromArgb(220, 224, 228);
        _overallStatus.TextAlign = ContentAlignment.MiddleLeft;

        var exeState = new Label
        {
            Text = "ID8 EXE: Detected",
            AutoSize = true,
            Font = new Font("Segoe UI", 10F, FontStyle.Bold),
            ForeColor = Color.FromArgb(127, 228, 150),
            Dock = DockStyle.Right,
            TextAlign = ContentAlignment.MiddleRight,
            Margin = new Padding(12, 0, 0, 0)
        };

        statusBar.Controls.Add(_overallStatus);
        statusBar.Controls.Add(exeState);

        var inputSettingsHost = new TableLayoutPanel
        {
            Dock = DockStyle.Bottom,
            Height = 86,
            ColumnCount = 2,
            RowCount = 2,
            BackColor = Color.FromArgb(17, 20, 25),
            Margin = new Padding(0, 8, 0, 0),
            Padding = new Padding(0, 8, 0, 0)
        };
        inputSettingsHost.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 180F));
        inputSettingsHost.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
        inputSettingsHost.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
        inputSettingsHost.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));

        _inputSettingsButton.Margin = new Padding(0, 0, 10, 6);
        _inputSettingsButton.Dock = DockStyle.Fill;
        _inputSettingsButton.Width = 0;
        _inputSettingsButton.Height = 0;

        _enableCardReader.Margin = new Padding(4, 0, 0, 4);
        _enableCardReader.Anchor = AnchorStyles.Left | AnchorStyles.Top;
        _showLoaderWindow.Margin = new Padding(4, 0, 0, 4);
        _showLoaderWindow.Anchor = AnchorStyles.Left | AnchorStyles.Top;

        inputSettingsHost.Controls.Add(_inputSettingsButton, 0, 0);
        inputSettingsHost.SetRowSpan(_inputSettingsButton, 2);
        inputSettingsHost.Controls.Add(_enableCardReader, 1, 0);
        inputSettingsHost.Controls.Add(_showLoaderWindow, 1, 1);

        rightPanel.Controls.Add(inputSettingsHost);
        rightPanel.Controls.Add(graphicsTable);

        content.Controls.Add(leftPanel, 0, 0);
        content.Controls.Add(rightPanel, 1, 0);

        root.Controls.Add(header, 0, 0);
        root.Controls.Add(content, 0, 1);
        root.Controls.Add(statusBar, 0, 2);

        Controls.Add(root);

        _loaderBox.ReadOnly = true;
        _loaderBox.TextChanged += (_, _) => UpdateStatus();
        _coreBox.ReadOnly = true;
        _coreBox.TextChanged += (_, _) => UpdateStatus();
        _romBox.ReadOnly = true;
        _romBox.TextChanged += (_, _) => { RefreshGameList(); UpdateStatus(); };
        _loaderBox.BackColor = Color.FromArgb(25, 30, 37);
        _loaderBox.ForeColor = Color.FromArgb(240, 242, 245);
        _loaderBox.BorderStyle = BorderStyle.FixedSingle;
        _loaderBox.Height = 23;
        _loaderBox.Width = 100;
        _coreBox.BackColor = Color.FromArgb(25, 30, 37);
        _coreBox.ForeColor = Color.FromArgb(240, 242, 245);
        _coreBox.BorderStyle = BorderStyle.FixedSingle;
        _coreBox.Height = 23;
        _coreBox.Width = 100;
        _romBox.BackColor = Color.FromArgb(25, 30, 37);
        _romBox.ForeColor = Color.FromArgb(240, 242, 245);
        _romBox.BorderStyle = BorderStyle.FixedSingle;
        _romBox.Height = 23;
        _romBox.Width = 100;
        _gameBox.Height = 23;
        _loaderStatus.ForeColor = Color.FromArgb(127, 228, 150);
        _coreStatus.ForeColor = Color.FromArgb(127, 228, 150);
        _gameStatus.ForeColor = Color.FromArgb(127, 228, 150);

        leftTable.Controls.Remove(exeCaption);
        leftTable.Controls.Remove(_gameBox);
        leftTable.Controls.Remove(_gameStatus);
        leftTable.Controls.Remove(actionRow);

        var addressBarPanel = new FlowLayoutPanel
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false,
            Margin = new Padding(0),
            Padding = new Padding(0)
        };

        var pathFields = new (string Name, TextBox Box, Label? Status)[]
        {
            ("OpenParrotLoader", _loaderBox, _loaderStatus),
            ("TeknoParrot.dll", _coreBox, _coreStatus),
            ("ROM Folder", _romBox, null)
        };

        foreach (var field in pathFields)
        {
            var fieldPanel = new Panel
            {
                Dock = DockStyle.Top,
                AutoSize = false,
                Height = 64,
                Margin = new Padding(0, 0, 0, 10),
                BackColor = Color.FromArgb(17, 20, 25)
            };

            var label = new Label
            {
                Text = field.Name,
                AutoSize = true,
                ForeColor = Color.FromArgb(173, 183, 194),
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                Location = new Point(0, 0)
            };

            var box = field.Box;
            box.Location = new Point(0, 18);
            box.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            box.Width = 420;
            box.Height = 23;
            box.BorderStyle = BorderStyle.FixedSingle;
            box.BackColor = Color.FromArgb(25, 30, 37);
            box.ForeColor = Color.FromArgb(240, 242, 245);

            var status = field.Status;
            if (status is not null)
            {
                status.Location = new Point(0, 44);
                status.AutoSize = true;
                status.ForeColor = Color.FromArgb(127, 228, 150);
                fieldPanel.Controls.Add(status);
            }

            fieldPanel.Controls.Add(label);
            fieldPanel.Controls.Add(box);
            addressBarPanel.Controls.Add(fieldPanel);
        }

        leftTable.Controls.Add(addressBarPanel, 0, 1);
        leftTable.Controls.Add(exeCaption, 0, 2);
        leftTable.Controls.Add(_gameBox, 0, 3);
        leftTable.Controls.Add(_gameStatus, 0, 4);
        leftTable.Controls.Add(actionRow, 0, 5);

        leftTable.RowStyles.Clear();
        leftTable.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        leftTable.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        leftTable.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        leftTable.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        leftTable.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        leftTable.RowStyles.Add(new RowStyle(SizeType.AutoSize));
    }

    private static void AddSettingRow(TableLayoutPanel table, int row, string labelText, Control control)
    {
        var label = new Label
        {
            Text = labelText,
            AutoSize = true,
            Anchor = AnchorStyles.Left,
            ForeColor = Color.FromArgb(186, 194, 203),
            Font = new Font("Segoe UI", 9F),
            Margin = new Padding(0, 6, 0, 6)
        };

        control.Anchor = AnchorStyles.Left | AnchorStyles.Right;
        control.Margin = new Padding(0, 4, 0, 4);

        table.Controls.Add(label, 0, row);
        table.Controls.Add(control, 1, row);
    }

    private static Label MakeLabel(string text, int x, int y) => new()
    {
        Text = text,
        AutoSize = true,
        Location = new Point(x, y)
    };

    private static Button MakeButton(string text, int x, int y, int width, int height) => new()
    {
        Text = text,
        Location = new Point(x, y),
        Size = new Size(width, height)
    };

    private void NormalizePaths()
    {
        if (string.IsNullOrWhiteSpace(_loaderBox.Text))
            _loaderBox.Text = ToRelativeDisplayPath(ResolveLoaderPath());

        if (string.IsNullOrWhiteSpace(_coreBox.Text))
            _coreBox.Text = ToRelativeDisplayPath(ResolveCorePath());

        if (string.IsNullOrWhiteSpace(_romBox.Text))
            _romBox.Text = ToRelativeDisplayPath(ResolveRomPath());
    }

    private void RefreshGameList()
    {
        var previous = _gameBox.SelectedItem as string;
        _gameBox.Items.Clear();

        var rom = ResolveRomPath();
        if (!Directory.Exists(rom))
        {
            UpdateGameStatus();
            return;
        }

        var games = Directory.EnumerateFiles(rom, "*.exe", SearchOption.AllDirectories)
            .Where(IsId8Executable)
            .OrderBy(p => !string.Equals(Path.GetFileName(p), "InitialD8_GLW_RE_SBZZ_dumped_.exe", StringComparison.OrdinalIgnoreCase))
            .ThenBy(p => p, StringComparer.OrdinalIgnoreCase)
            .ToArray();

        foreach (var game in games)
            _gameBox.Items.Add(game);

        if (previous is not null)
        {
            var index = _gameBox.Items.IndexOf(previous);
            if (index >= 0)
                _gameBox.SelectedIndex = index;
        }

        if (_gameBox.SelectedIndex < 0 && _gameBox.Items.Count > 0)
            _gameBox.SelectedIndex = 0;

        LoadSelectedGameSettings();
        UpdateGameStatus();
    }

    private string? TryGetSelectedGameIniPath()
    {
        var game = _gameBox.SelectedItem as string;
        if (string.IsNullOrWhiteSpace(game) || !File.Exists(game))
            return null;

        var directory = Path.GetDirectoryName(game);
        if (string.IsNullOrWhiteSpace(directory))
            return null;

        return Path.Combine(directory, "teknoparrot.ini");
    }

    private void LoadSelectedGameSettings()
    {
        var iniPath = TryGetSelectedGameIniPath();
        _currentGraphicsConfig = string.IsNullOrWhiteSpace(iniPath) || !File.Exists(iniPath)
            ? Id8Config.CreateDefault()
            : Id8Config.FromIniFile(iniPath);

        ApplyGraphicsConfigToUi(_currentGraphicsConfig);
    }

    private void ResetGraphicsSettings()
    {
        _currentGraphicsConfig = Id8Config.CreateDefault();
        ApplyGraphicsConfigToUi(_currentGraphicsConfig);
    }

    private void ApplyGraphicsConfigToUi(Id8Config config)
    {
        _resolutionWidthBox.Value = Math.Clamp(Convert.ToInt32(config.ResolutionWidth), (int)_resolutionWidthBox.Minimum, (int)_resolutionWidthBox.Maximum);
        _resolutionHeightBox.Value = Math.Clamp(Convert.ToInt32(config.ResolutionHeight), (int)_resolutionHeightBox.Minimum, (int)_resolutionHeightBox.Maximum);
        _windowModeBox.SelectedIndex = string.Equals(config.Windowed, "1", StringComparison.OrdinalIgnoreCase) ? 0 : 1;
        _resolutionModeBox.SelectedIndex = string.Equals(config.ResolutionMode, "Game", StringComparison.OrdinalIgnoreCase) ? 1 : 0;
        _renderResolutionBox.SelectedIndex = config.RenderResolution switch
        {
            "Auto" => 0,
            "Stock" => 1,
            "1.5x" => 2,
            "2x" => 3,
            _ => 0
        };
        _linearFilteringBox.Checked = string.Equals(config.LinearFiltering, "1", StringComparison.OrdinalIgnoreCase);
        _framelimiterBox.Checked = string.Equals(config.Framelimiter, "1", StringComparison.OrdinalIgnoreCase);
        _gpuFixBox.SelectedIndex = config.GPUFix switch
        {
            "None" => 0,
            "AMD" => 1,
            "New AMD Driver" => 2,
            "INTEL" => 3,
            _ => 0
        };
    }

    private Id8Config ReadGraphicsConfigFromUi()
    {
        var config = Id8Config.CreateDefault();
        config.ResolutionWidth = _resolutionWidthBox.Value.ToString();
        config.ResolutionHeight = _resolutionHeightBox.Value.ToString();
        config.Windowed = _windowModeBox.SelectedIndex == 0 ? "1" : "0";
        config.ResolutionMode = _resolutionModeBox.SelectedItem?.ToString() ?? "Upscale";
        config.RenderResolution = _renderResolutionBox.SelectedItem?.ToString() ?? "Auto";
        config.LinearFiltering = _linearFilteringBox.Checked ? "1" : "0";
        config.Framelimiter = _framelimiterBox.Checked ? "1" : "0";
        config.GPUFix = _gpuFixBox.SelectedItem?.ToString() ?? "None";
        return config;
    }

    private void SaveCurrentGraphicsSettings()
    {
        var game = _gameBox.SelectedItem as string;
        if (string.IsNullOrWhiteSpace(game) || !File.Exists(game))
            return;

        var config = ReadGraphicsConfigFromUi();
        config.InputAPI = InputManager.Instance.Api.ToString();
        var writer = new Id8ConfigWriter(config);
        writer.Write(game);
        _currentGraphicsConfig = config;
    }

    private static bool IsId8Executable(string path)
    {
        var name = Path.GetFileNameWithoutExtension(path);
        if (string.IsNullOrWhiteSpace(name))
            return false;

        if (name.Equals("InitialD8_GLW_RE_SBZZ_dumped_", StringComparison.OrdinalIgnoreCase))
            return true;

        return name.Contains("InitialD8", StringComparison.OrdinalIgnoreCase);
    }

    private void UpdateGameStatus()
    {
        _gameStatus.Text = _gameBox.Items.Count switch
        {
            0 => "✗ InitialD8-related EXE not found",
            1 when _gameBox.Items[0] is string gamePath => $"✓ Found: {Path.GetFileName(gamePath)}",
            1 => "✓ Found: InitialD8-related EXE",
            var n => $"✓ Found {n} candidate EXEs; select one from the drop-down"
        };
        _gameStatus.ForeColor = _gameBox.Items.Count > 0 ? Color.DarkGreen : Color.DarkRed;
    }

    private void UpdateStatus(string? message = null)
    {
        var loaderPath = ResolveLoaderPath();
        var loaderOk = File.Exists(loaderPath);
        var core = ResolveCorePath();
        var coreExists = File.Exists(core);
        var coreX86 = coreExists && Is32BitPeFile(core);
        var gameOk = _gameBox.SelectedItem is string game && File.Exists(game);

        _loaderStatus.Text = loaderOk
            ? $"✓ Detected: {ToRelativeDisplayPath(loaderPath)}"
            : "✗ OpenParrotLoader.exe not found";
        _loaderStatus.ForeColor = loaderOk ? Color.DarkGreen : Color.DarkRed;

        _coreStatus.Text = !coreExists
            ? $"✗ TeknoParrot.dll not found (current detection: {ToRelativeDisplayPath(core)})"
            : coreX86
                ? $"✓ Detected: {ToRelativeDisplayPath(core)} · {GetFileVersion(core)}"
                : $"✗ DLL exists, but is not x86: {ToRelativeDisplayPath(core)}";
        _coreStatus.ForeColor = coreX86 ? Color.DarkGreen : Color.DarkRed;

        UpdateGameStatus();

        _launchButton.Enabled = loaderOk && coreX86 && gameOk;
        _overallStatus.Text = message is not null
            ? $"Status: {message}"
            : _launchButton.Enabled
                ? $"Status: ✓ Ready to launch · Loader={ToRelativeDisplayPath(loaderPath)}"
                : $"Status: Please check the items above · Loader={ToRelativeDisplayPath(loaderPath)}";
    }

    private void SaveConfig()
    {
        try
        {
            Directory.CreateDirectory(ConfigDir);
            var config = new LauncherConfig
            {
                LoaderPath = ResolveLoaderPath(),
                TeknoParrotDll = ResolveCorePath(),
                RomDirectory = ResolveRomPath(),
                EnableCardReader = _enableCardReader.Checked,
                ShowLoaderWindow = _showLoaderWindow.Checked
            };

            File.WriteAllText(
                ConfigPath,
                JsonSerializer.Serialize(config, new JsonSerializerOptions { WriteIndented = true }));
        }
        catch
        {
            // A config write failure should not prevent launching.
        }
    }

    private static string ToRelativeDisplayPath(string fullPath)
    {
        if (string.IsNullOrWhiteSpace(fullPath))
            return string.Empty;

        try
        {
            var baseDirUri = new Uri(AppContext.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar) + Path.DirectorySeparatorChar);
            var fullUri = new Uri(fullPath);
            var relative = baseDirUri.MakeRelativeUri(fullUri).ToString().Replace('/', Path.DirectorySeparatorChar);
            return relative;
        }
        catch
        {
            return fullPath;
        }
    }

    private void LoadConfig()
    {
        _loaderBox.Text = ToRelativeDisplayPath(ResolveLoaderPath());
        _coreBox.Text = ToRelativeDisplayPath(ResolveCorePath());
        _romBox.Text = ToRelativeDisplayPath(ResolveRomPath());

        // Paths are fixed to the launcher directory. Only launcher preferences are loaded.
        try
        {
            if (!File.Exists(ConfigPath))
                return;

            var json = File.ReadAllText(ConfigPath);
            var config = JsonSerializer.Deserialize<LauncherConfig>(json);
            if (config is null)
                return;

            _enableCardReader.Checked = config.EnableCardReader;
            _showLoaderWindow.Checked = config.ShowLoaderWindow;
        }
        catch
        {
            // Invalid preference data should not prevent launching.
        }
    }

    private void LaunchGame(bool testMode)
    {
        var game = _gameBox.SelectedItem as string;
        var core = ResolveCorePath();
        var loaderPath = ResolveLoaderPath();

        if (!File.Exists(loaderPath))
        {
            ShowError($"找不到 OpenParrotLoader.exe。\n\n当前路径：\n{ToRelativeDisplayPath(loaderPath)}");
            return;
        }

        if (!File.Exists(core))
        {
            ShowError($"找不到 TeknoParrot.dll。\n\n默认位置：\n{ToRelativeDisplayPath(DefaultCorePath)}");
            return;
        }

        if (!Is32BitPeFile(core))
        {
            ShowError("选择的 TeknoParrot.dll 不是 x86 (32 位) DLL。\nID8 使用 x86 Core。");
            return;
        }

        if (string.IsNullOrWhiteSpace(game) || !File.Exists(game))
        {
            ShowError("rom 文件夹里没有可启动的 InitialD8 主程序（例如 InitialD8_GLW_RE_SBZZ_dumped_.exe）。");
            return;
        }

        try
        {
            SaveCurrentGraphicsSettings();

            var gameProfile = new GameProfile
            {
                ProfileName = Path.GetFileName(game),
                GamePath = Path.GetFullPath(game),
                EmulationProfile = EmulationProfile.SegaInitialD,
                AllowSettingSync = false
            };

            InputCode.ButtonMode = gameProfile.EmulationProfile;
            InputCode.GameProfile = gameProfile;
            JvsHelper.ResetState();
            JvsPackageEmulator.Initialize(gameProfile);

            Debug.WriteLine("[TP] EmulationProfile: SegaInitialD");
            Debug.WriteLine($"[TP] Launch mode: {(testMode ? "SEPARATE TEST MODE (-t)" : "NORMAL GAME")}");
            Debug.WriteLine("[TP] Configuration written");

            var serialPortHandler = new SerialPortHandler();
            serialPortHandler.StopListening();

            var pipeThread = new Thread(() => serialPortHandler.ListenPipe(JvsConstants.PipeName))
            {
                IsBackground = true,
                Name = "InitialD8JvsPipe"
            };
            pipeThread.Start();

            var queueThread = new Thread(serialPortHandler.ProcessQueue)
            {
                IsBackground = true,
                Name = "InitialD8JvsQueue"
            };
            queueThread.Start();

            _inputListener.Start();

            var iniPath = TryGetSelectedGameIniPath();
            if (!string.IsNullOrWhiteSpace(iniPath))
            {
                Debug.WriteLine($"ID8 config path: {iniPath}");
                Debug.WriteLine("ID8 config content:");
                Debug.WriteLine(File.ReadAllText(iniPath));
            }

            var coreArgument = @".\TeknoParrot";
            var processManager = new GameProcessManager();

            if (_enableCardReader.Checked)
            {
                var gameDirectory = Path.GetDirectoryName(Path.GetFullPath(game));
                var picodaemonPath = string.IsNullOrWhiteSpace(gameDirectory)
                    ? null
                    : Path.Combine(gameDirectory, "picodaemon.exe");

                if (string.IsNullOrWhiteSpace(picodaemonPath) || !File.Exists(picodaemonPath))
                {
                    Debug.WriteLine("[CARD] picodaemon.exe not found next to the selected ID8 EXE; continuing without card reader.");
                    UpdateStatus(testMode
                        ? "已提交 TEST MODE（-t），但未找到 picodaemon.exe"
                        : "已提交启动，但未找到 picodaemon.exe");
                }
                else
                {
                    var cardCoreArgument = File.Exists(
                        Path.Combine(BaseDir, "TeknoParrot", "TeknoParrot"))
                        ? @".\TeknoParrot\TeknoParrot"
                        : coreArgument;

                    var cardProcess = CardReaderManager.Start(
                        loaderPath,
                        picodaemonPath,
                        cardCoreArgument,
                        !_showLoaderWindow.Checked,
                        BaseDir);

                    if (cardProcess is not null)
                    {
                        Debug.WriteLine($"[CARD] Picodaemon loader started. PID={cardProcess.Id}");
                        Thread.Sleep(500);
                    }
                    else
                    {
                        Debug.WriteLine("[CARD] An existing picodaemon.exe was detected; reusing it.");
                        Thread.Sleep(250);
                    }
                }
            }

            processManager.CreateGameProcess(
                loaderPath,
                game,
                coreArgument,
                !_showLoaderWindow.Checked,
                BaseDir,
                testMode,
                "-t");

            Debug.WriteLine($"[TP] Launching OpenParrotLoader {(testMode ? "in TEST MODE" : "normally")}");
            SaveConfig();
            UpdateStatus(testMode
                ? (_enableCardReader.Checked ? "已提交 TEST MODE（-t）+ 卡片读写器" : "已提交 TEST MODE 启动（-t）")
                : (_enableCardReader.Checked ? "已提交启动 + 卡片读写器" : "已提交启动"));
        }
        catch (Exception ex)
        {
            ShowError($"调用 OpenParrotLoader 失败：\n\n{ex.Message}");
        }
    }

    private void ShowError(string message) => MessageBox.Show(
        this, message, "无法启动", MessageBoxButtons.OK, MessageBoxIcon.Error);

    private static string GetFileVersion(string path)
    {
        try
        {
            return FileVersionInfo.GetVersionInfo(path).FileVersion ?? "未知版本";
        }
        catch
        {
            return "未知版本";
        }
    }

    private static bool Is32BitPeFile(string path)
    {
        try
        {
            using var fs = File.OpenRead(path);
            using var br = new BinaryReader(fs);

            if (br.ReadUInt16() != 0x5A4D)
                return false;

            fs.Position = 0x3C;
            var peOffset = br.ReadInt32();
            fs.Position = peOffset;

            if (br.ReadUInt32() != 0x00004550)
                return false;

            // IMAGE_FILE_HEADER.Machine
            return br.ReadUInt16() == 0x014C; // IMAGE_FILE_MACHINE_I386
        }
        catch
        {
            return false;
        }
    }

    private sealed class LauncherConfig
    {
        public string? LoaderPath { get; set; }
        public string? TeknoParrotDll { get; set; }
        public string? RomDirectory { get; set; }
        public bool EnableCardReader { get; set; } = true;
        public bool ShowLoaderWindow { get; set; }
    }
}
