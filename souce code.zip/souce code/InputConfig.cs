#nullable enable
using System.Text.Json;

namespace InitialD8Launcher;

public sealed class InputConfig
{
    public string InputApi { get; set; } = nameof(InitialD8Launcher.InputApi.DirectInput);
    public Dictionary<string, InputBinding> Bindings { get; set; } = new(StringComparer.OrdinalIgnoreCase);

    public static InputConfig CreateDefault()
    {
        var config = new InputConfig();
        foreach (var action in InputManager.ActionNames)
            config.Bindings[action] = new InputBinding { Api = config.InputApi };
        return config;
    }

    public static InputConfig Load(string path)
    {
        try
        {
            if (!File.Exists(path))
                return CreateDefault();

            var json = File.ReadAllText(path);
            var config = JsonSerializer.Deserialize<InputConfig>(json, new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            }) ?? CreateDefault();

            config.Bindings ??= new Dictionary<string, InputBinding>(StringComparer.OrdinalIgnoreCase);
            foreach (var action in InputManager.ActionNames)
            {
                if (!config.Bindings.ContainsKey(action) || config.Bindings[action] is null)
                    config.Bindings[action] = new InputBinding { Api = config.InputApi };
            }

            return config;
        }
        catch
        {
            return CreateDefault();
        }
    }

    public void Save(string path)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        File.WriteAllText(path, JsonSerializer.Serialize(this, new JsonSerializerOptions
        {
            WriteIndented = true
        }));
    }
}
