#nullable enable
namespace InitialD8Launcher;

public static class JVSIdentifiers
{
    public const string Sega2005Jvs14572 = "SEGA CORPORATION;I/O BD JVS;837-14572;Ver1.00;2005/10\0";
    public const string SegaLetsGoSafari = "SEGA CORPORATION;I/O BD JVS;837-14895;1;1;FE MODE;2005/10\0";
    public const string SegaXiyangyang = "SEGA CORPORATION;I/O BD FE/JVS;837-14895;Ver1.00;2009/07,FE MODE\0";
    public const string NBGI_MarioKart3 = "NBGI.;NA-JV;Ver6.01;JPN,MK3100-1-NA-APR0-A01\0";
    public const string NBGI_Pokken = "namco ltd.;NA-JV;Ver4.01;JPN,MK3100-1-NA-APR0-A01\0";
    public const string NamcoMultipurpose = "namco ltd.;NA-JV;Ver4.00;JPN,Multipurpose.\0";
}
