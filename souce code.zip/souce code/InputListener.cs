#nullable enable
using System.Diagnostics;

namespace InitialD8Launcher;

public sealed class InputListener
{
    public void Start()
    {
        InputManager.Instance.Start();
        Debug.WriteLine("[TP] Input listener started");
    }

    public void Stop()
    {
        InputManager.Instance.Stop();
    }
}
