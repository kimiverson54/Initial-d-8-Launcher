#nullable disable
using System.Collections.Concurrent;
using System.Diagnostics;
using System.IO.Pipes;
using System.IO.Ports;

namespace InitialD8Launcher;

/// <summary>
/// JVS transport adapted from TeknoParrotUI's SerialPortHandler.
/// </summary>
public sealed class SerialPortHandler
{
    private readonly ConcurrentQueue<byte> _receivedData = new();
    private static NamedPipeServerStream _npServer;
    private static string _pipe;
    private static bool KillMe { get; set; }
    private const int TargetElapsedMilliseconds = 10;
    private readonly Stopwatch _stopwatchDeque = new();
    private readonly SpinWait _spinWaitDeque = new();
    private Stream _stream;
    private static readonly object LogSync = new();

    public void ProcessQueue()
    {
        Thread.CurrentThread.Priority = ThreadPriority.Highest;
        var stopwatch = new Stopwatch();
        var spinWait = new SpinWait();
        Log("[JVS] ProcessQueue started");

        while (true)
        {
            stopwatch.Restart();
            try
            {
                if (QueueProcessor())
                    return;

                while (stopwatch.ElapsedMilliseconds < TargetElapsedMilliseconds)
                    spinWait.SpinOnce();
            }
            catch (Exception ex)
            {
                LogError(ex, "ProcessQueue");
            }
        }
    }

    private bool QueueProcessor()
    {
        if (KillMe)
            return true;

        var queue = new List<byte>();
        if (_receivedData.Count == 0)
            return false;

        var first = DeQueueByte();
        if (first == 0xE0)
        {
            var count = 0;
            byte size = 0;
            while (true)
            {
                if (KillMe)
                    return true;

                if (count == 0)
                {
                    queue.Add(first);
                    count++;
                }
                else if (_receivedData.Count > 2 && count == 1)
                {
                    queue.Add(DeQueueByte());
                    size = DeQueueByte();
                    queue.Add(size);
                    count++;
                }
                else if (count == 2 && _receivedData.Count >= size)
                {
                    for (var i = 0; i < size; i++)
                        queue.Add(DeQueueByte());

                    var packet = queue.ToArray();
                    Log($"[JVS] RX: {FormatHex(packet)}");
                    var reply = JvsPackageEmulator.GetReply(packet);
                    if (reply.Length != 0)
                    {
                        Log($"[JVS] TX: {FormatHex(reply)}");
                        _stream?.Write(reply, 0, reply.Length);
                    }
                    break;
                }
            }
        }

        return false;
    }

    public byte DeQueueByte()
    {
        while (true)
        {
            _stopwatchDeque.Restart();
            if (_receivedData.TryDequeue(out var value))
                return value;

            while (_stopwatchDeque.ElapsedMilliseconds < TargetElapsedMilliseconds)
                _spinWaitDeque.SpinOnce();
        }
    }

    public void ListenPipe(string pipe)
    {
        Thread.CurrentThread.Priority = ThreadPriority.Highest;
        KillMe = false;
        _pipe = pipe;
        _npServer?.Close();
        _npServer = new NamedPipeServerStream(
            pipe,
            PipeDirection.InOut,
            1,
            PipeTransmissionMode.Byte,
            PipeOptions.Asynchronous);

        Log($"[JVS] Pipe created: {pipe}");
        Log("[JVS] Waiting for client...");

        while (true)
        {
            try
            {
                _npServer.WaitForConnection();
                _stream = _npServer;
                Log("[JVS] Client connected");

                while (true)
                {
                    if (KillMe)
                    {
                        _npServer.Close();
                        return;
                    }

                    var data = new byte[1024];
                    var read = _npServer.Read(data, 0, data.Length);
                    if (read == 0)
                    {
                        _npServer.Close();
                        _npServer = new NamedPipeServerStream(
                            pipe,
                            PipeDirection.InOut,
                            1,
                            PipeTransmissionMode.Byte,
                            PipeOptions.Asynchronous);
                        Log("[JVS] Client disconnected; waiting for client...");
                        break;
                    }

                    for (var i = 0; i < read; i++)
                    {
                        if (data[i] == 0xD0 && i + 1 != read)
                        {
                            if (data[i + 1] == 0xCF || data[i + 1] == 0xDF)
                            {
                                i += 1;
                                if (data[i] == 0xCF)
                                    _receivedData.Enqueue(0xD0);
                                else
                                    _receivedData.Enqueue(0xE0);
                                continue;
                            }
                        }

                        _receivedData.Enqueue(data[i]);
                    }
                }
            }
            catch (Exception ex)
            {
                LogError(ex, "ListenPipe");
                try { _npServer?.Close(); } catch { }
                if (KillMe)
                    return;
                _npServer = new NamedPipeServerStream(
                    pipe,
                    PipeDirection.InOut,
                    1,
                    PipeTransmissionMode.Byte,
                    PipeOptions.Asynchronous);
                Log("[JVS] Pipe recreated; waiting for client...");
            }
        }
    }

    public void ListenSerial(string port)
    {
        KillMe = false;
        using var serial = new SerialPort(port)
        {
            BaudRate = 115200,
            Parity = Parity.None,
            StopBits = StopBits.One,
            ReadTimeout = 0,
            WriteBufferSize = 516,
            ReadBufferSize = 516,
            Handshake = Handshake.None
        };

        serial.DataReceived += (_, _) =>
        {
            var available = serial.BytesToRead;
            if (available <= 0)
                return;

            var data = new byte[available];
            var read = serial.Read(data, 0, data.Length);
            for (var i = 0; i < read; i++)
            {
                if (data[i] == 0xD0 && i + 1 != read &&
                    (data[i + 1] == 0xCF || data[i + 1] == 0xDF))
                {
                    i++;
                    _receivedData.Enqueue(data[i] == 0xCF ? (byte)0xD0 : (byte)0xE0);
                    continue;
                }

                _receivedData.Enqueue(data[i]);
            }
        };

        serial.Open();
        while (!KillMe)
            Thread.Sleep(10);
    }

    public void StopListening()
    {
        if (string.IsNullOrEmpty(_pipe))
            return;

        KillMe = true;
        try
        {
            using var client = new NamedPipeClientStream(_pipe);
            client.Connect(100);
        }
        catch
        {
            // Ignore wake-up connection failures.
        }
    }

    private static void Log(string message)
    {
        Debug.WriteLine(message);
        try
        {
            lock (LogSync)
            {
                File.AppendAllText(
                    Path.Combine(AppContext.BaseDirectory, "jvs.log"),
                    message + Environment.NewLine);
            }
        }
        catch
        {
            // Logging failure must never break JVS processing.
        }
    }

    private static void LogError(Exception ex, string context)
    {
        Log($"[JVS] ERROR: {context} :: {ex.GetType().Name}: {ex.Message}");
    }

    private static string FormatHex(byte[] data)
    {
        return BitConverter.ToString(data).Replace("-", " ");
    }
}
