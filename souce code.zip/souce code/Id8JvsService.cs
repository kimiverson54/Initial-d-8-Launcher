#nullable enable
namespace InitialD8Launcher;

// Deprecated compatibility shell retained so older references do not break.
// The active JVS server is SerialPortHandler + JvsPackageEmulator.
public sealed class Id8JvsService : IDisposable
{
    private static readonly Lazy<Id8JvsService> InstanceValue = new(() => new Id8JvsService());
    public static Id8JvsService Instance => InstanceValue.Value;
    private Id8JvsService() { }
    public void Start() { }
    public void Stop() { }
    public void Dispose() { }
}
