# Third-party notices

This launcher is distributed under the GNU General Public License v3.0
(GPL-3.0). See [LICENSE](LICENSE) for the full text. It incorporates or adapts
the third-party components listed below.

## TeknoParrotUI (GPL-3.0)

The launcher contains adapted JVS protocol/transport and input-model source
derived from the GPL-3.0 licensed TeknoParrotUI project:

- <https://github.com/teknogods/TeknoParrotUI>

This includes the JVS serial/pipe transport (`SerialPortHandler`), the JVS
package emulator and reply logic (`JvsPackageEmulator`), and related JVS
helpers. The corresponding GPL-3.0 obligations apply to the adapted source.

## OpenParrot (GPL-3.0)

The `OpenParrotWin32` runtime components shipped with the project (for example
`OpenParrotLoader.exe` and `OpenParrot.dll`) are GPL-3.0 code from the
TeknoParrot/OpenParrot ecosystem. If you redistribute these binaries, comply with
the GPL-3.0 redistribution requirements, including preserving copyright notices,
the license text, and the source-availability obligation.

## SharpDX

This launcher references the `SharpDX.DirectInput` and `SharpDX.XInput` NuGet
packages for controller access. See the package/project license information
distributed with those packages.

## Not included

The following are not distributed with this project and must be provided by the
user: the Initial D 8 game files, the TeknoParrot core (`TeknoParrot.dll`), and
the card-reader daemon (`picodaemon.exe`).

## Trademarks

Initial D and related marks are the property of their respective owners. This
project is not affiliated with or endorsed by SEGA.
