#nullable enable
using SharpDX.DirectInput;
using SharpDX.XInput;
using System.Diagnostics;

namespace InitialD8Launcher;

public sealed class InputStateSnapshot
{
    public double WheelAxis { get; init; } = 0.0;
    public double Gas { get; init; } = 0.0;
    public double Brake { get; init; } = 0.0;
    public IReadOnlyDictionary<string, bool> Buttons { get; init; } = new Dictionary<string, bool>();
}

public sealed class InputManager : IDisposable
{
    public static readonly string[] ActionNames =
    {
        "Test", "Service", "Coin", "Start",
        "Wheel Axis", "Gas", "Brake",
        "Shift up", "Shift Down", "View Change",
        "Menu Up", "Menu Down", "Menu Left", "Menu Right",
        "Gear 1", "Gear 2", "Gear 3", "Gear 4", "Gear 5", "Gear 6"
    };

    public static InputManager Instance { get; } = new();

    private readonly object _sync = new();
    private readonly string _configPath = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
        "InitialD8Launcher",
        "input.json");

    private InputConfig _config = InputConfig.CreateDefault();
    private Thread? _thread;
    private volatile bool _running;
    private volatile bool _captureRequested;
    private string? _captureAction;
    private TaskCompletionSource<InputBinding?>? _captureCompletion;
    private InputStateSnapshot _snapshot = new();
    private DirectInput? _directInput;
    private readonly Dictionary<Guid, Joystick> _directDevices = new();
    private long _lastDirectRefresh;

    private InputManager() { }

    public InputApi Api
    {
        get => Enum.TryParse<InputApi>(_config.InputApi, true, out var api) ? api : InputApi.DirectInput;
        set
        {
            lock (_sync)
                _config.InputApi = value.ToString();
        }
    }

    public void Load()
    {
        lock (_sync)
            _config = InputConfig.Load(_configPath);
    }

    public void Save()
    {
        lock (_sync)
            _config.Save(_configPath);
    }

    public InputBinding GetBinding(string action)
    {
        lock (_sync)
        {
            if (!_config.Bindings.TryGetValue(action, out var binding) || binding is null)
            {
                binding = new InputBinding { Api = Api.ToString() };
                _config.Bindings[action] = binding;
            }
            return binding.Clone();
        }
    }

    public void SetBinding(string action, InputBinding binding)
    {
        lock (_sync)
        {
            binding.Api = Api.ToString();
            _config.Bindings[action] = binding.Clone();
        }
    }

    public void ClearBinding(string action)
    {
        lock (_sync)
            _config.Bindings[action] = new InputBinding { Api = Api.ToString() };
    }

    public void Start()
    {
        if (_running)
            return;

        Load();
        if (Api == InputApi.DirectInput)
            EnsureDirectInputDevices();
        _running = true;
        _thread = new Thread(PollLoop)
        {
            IsBackground = true,
            Name = "InitialD8InputListener"
        };
        _thread.Start();
        Debug.WriteLine("[Input] Listener started");
    }

    public void Stop()
    {
        _running = false;
        try { _thread?.Join(1000); } catch { }
        _thread = null;
        DisposeDirectInputDevices();
        Debug.WriteLine("[Input] Listener stopped");
    }

    public InputStateSnapshot GetSnapshot()
    {
        lock (_sync)
            return _snapshot;
    }

    public Task<InputBinding?> CaptureBindingAsync(string action)
    {
        lock (_sync)
        {
            if (_captureRequested)
                throw new InvalidOperationException("Another input capture is already running.");

            _captureRequested = true;
            _captureAction = action;
            _captureCompletion = new TaskCompletionSource<InputBinding?>(TaskCreationOptions.RunContinuationsAsynchronously);
            return _captureCompletion.Task;
        }
    }

    public void SaveNow() => Save();

    private void PollLoop()
    {
        while (_running)
        {
            try
            {
                InputStateSnapshot snapshot = Api == InputApi.XInput
                    ? PollXInput()
                    : PollDirectInput();

                lock (_sync)
                    _snapshot = snapshot;

                ApplyToInputCode(snapshot);

                if (_captureRequested)
                    TryCapture();
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[Input] Poll error: {ex.Message}");
            }

            Thread.Sleep(8);
        }
    }

    private InputStateSnapshot PollDirectInput()
    {
        if (Environment.TickCount64 - _lastDirectRefresh > 2000)
            EnsureDirectInputDevices();

        var buttons = new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase);
        foreach (var action in ActionNames)
            buttons[action] = false;

        double wheel = 0;
        double gas = 0;
        double brake = 0;

        InputBinding[] bindings;
        lock (_sync)
            bindings = _config.Bindings.ToDictionary(p => p.Key, p => p.Value.Clone(), StringComparer.OrdinalIgnoreCase).Values.ToArray();

        foreach (var pair in _directDevices.ToArray())
        {
            try
            {
                var joystick = pair.Value;
                joystick.Poll();
                var state = joystick.GetCurrentState();

                foreach (var action in ActionNames)
                {
                    var binding = GetBinding(action);
                    if (!binding.IsBound ||
                        !binding.Api.Equals(nameof(InputApi.DirectInput), StringComparison.OrdinalIgnoreCase) ||
                        !binding.DeviceGuid.Equals(pair.Key.ToString(), StringComparison.OrdinalIgnoreCase))
                        continue;

                    if (binding.Kind == InputBindingKind.Axis)
                    {
                        var raw = GetDirectInputAxis(state, binding.Input);
                        if (!raw.HasValue) continue;
                        var value = NormalizeAxis(raw.Value, IsCenteredAction(action), binding.Invert, binding.Deadzone);
                        if (action.Equals("Wheel Axis", StringComparison.OrdinalIgnoreCase)) wheel = value;
                        else if (action.Equals("Gas", StringComparison.OrdinalIgnoreCase)) gas = value;
                        else if (action.Equals("Brake", StringComparison.OrdinalIgnoreCase)) brake = value;
                    }
                    else if (binding.Kind == InputBindingKind.Button)
                    {
                        buttons[action] = state.Buttons.Length > binding.Index && state.Buttons[binding.Index];
                    }
                    else if (binding.Kind == InputBindingKind.Pov)
                    {
                        var pov = state.PointOfViewControllers.Length > binding.Index ? state.PointOfViewControllers[binding.Index] : -1;
                        buttons[action] = PovPressed(pov, binding.Input);
                    }
                }
            }
            catch
            {
                // Device can disappear while the game is running; refresh on the next cycle.
            }
        }

        return new InputStateSnapshot { WheelAxis = wheel, Gas = gas, Brake = brake, Buttons = buttons };
    }

    private void EnsureDirectInputDevices()
    {
        try
        {
            _directInput ??= new DirectInput();
            var devices = _directInput.GetDevices(DeviceClass.GameControl, DeviceEnumerationFlags.AttachedOnly);
            var live = devices.Select(d => d.InstanceGuid).ToHashSet();

            foreach (var info in devices)
            {
                if (_directDevices.ContainsKey(info.InstanceGuid))
                    continue;

                try
                {
                    var joystick = new Joystick(_directInput, info.InstanceGuid);
                    joystick.SetCooperativeLevel(IntPtr.Zero, CooperativeLevel.NonExclusive | CooperativeLevel.Background);
                    joystick.Acquire();
                    _directDevices[info.InstanceGuid] = joystick;
                    Debug.WriteLine($"[Input] DirectInput device: {info.InstanceName} {info.InstanceGuid}");
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"[Input] DirectInput device open failed: {ex.Message}");
                }
            }

            foreach (var stale in _directDevices.Keys.Where(g => !live.Contains(g)).ToArray())
            {
                try { _directDevices[stale].Unacquire(); } catch { }
                _directDevices[stale].Dispose();
                _directDevices.Remove(stale);
            }
            _lastDirectRefresh = Environment.TickCount64;
        }
        catch (Exception ex)
        {
            Debug.WriteLine($"[Input] DirectInput initialization failed: {ex.Message}");
        }
    }

    private void DisposeDirectInputDevices()
    {
        foreach (var device in _directDevices.Values)
        {
            try { device.Unacquire(); } catch { }
            device.Dispose();
        }
        _directDevices.Clear();
        _directInput?.Dispose();
        _directInput = null;
    }

    private InputStateSnapshot PollXInput()
    {
        var buttons = new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase);
        foreach (var action in ActionNames)
            buttons[action] = false;

        double wheel = 0;
        double gas = 0;
        double brake = 0;

        for (var i = 0; i < 4; i++)
        {
            var controller = new Controller((UserIndex)i);
            if (!controller.IsConnected)
                continue;

            var state = controller.GetState();
            InputBinding[] bindings;
            lock (_sync) bindings = _config.Bindings.Values.Select(x => x.Clone()).ToArray();

            foreach (var action in ActionNames)
            {
                var binding = GetBinding(action);
                if (!binding.IsBound || !binding.Api.Equals(nameof(InputApi.XInput), StringComparison.OrdinalIgnoreCase) || binding.DeviceIndex != i)
                    continue;

                if (binding.Kind == InputBindingKind.Button)
                    buttons[action] = GetXInputButton(state.Gamepad.Buttons, binding.Input);
                else if (binding.Kind == InputBindingKind.Axis)
                {
                    var value = GetXInputAxisValue(state.Gamepad, binding.Input);
                    if (value.HasValue)
                    {
                        var normalized = NormalizeXInputAxisValue(value.Value, IsCenteredAction(action), binding.Invert, binding.Deadzone);
                        if (action.Equals("Wheel Axis", StringComparison.OrdinalIgnoreCase)) wheel = normalized;
                        else if (action.Equals("Gas", StringComparison.OrdinalIgnoreCase)) gas = normalized;
                        else if (action.Equals("Brake", StringComparison.OrdinalIgnoreCase)) brake = normalized;
                    }
                }
            }
        }

        return new InputStateSnapshot { WheelAxis = wheel, Gas = gas, Brake = brake, Buttons = buttons };
    }

    private void ApplyToInputCode(InputStateSnapshot snapshot)
    {
        // Official ID7 naming uses Analog0 for Wheel, Analog2 for Gas and Analog4 for Brake.
        InputCode.AnalogBytes[0] = ToJvsCenteredByte(snapshot.WheelAxis);
        InputCode.AnalogBytes[2] = ToJvsPositiveByte(snapshot.Gas);
        InputCode.AnalogBytes[4] = ToJvsPositiveByte(snapshot.Brake);

        SetDigital(0, d => d.Test = GetButton(snapshot, "Test"));
        SetDigital(0, d => d.Service = GetButton(snapshot, "Service"));
        SetDigital(0, d => d.Coin = GetButton(snapshot, "Coin"));
        SetDigital(0, d => d.Start = GetButton(snapshot, "Start"));

        SetDigital(1, d => d.Up = GetButton(snapshot, "Shift up"));
        SetDigital(1, d => d.Down = GetButton(snapshot, "Shift Down"));
        SetDigital(0, d => d.Button1 = GetButton(snapshot, "View Change"));

        SetDigital(0, d => d.Up = GetButton(snapshot, "Menu Up"));
        SetDigital(0, d => d.Down = GetButton(snapshot, "Menu Down"));
        SetDigital(0, d => d.Left = GetButton(snapshot, "Menu Left"));
        SetDigital(0, d => d.Right = GetButton(snapshot, "Menu Right"));

        SetDigital(1, d => d.Button1 = GetButton(snapshot, "Gear 1"));
        SetDigital(1, d => d.Button2 = GetButton(snapshot, "Gear 2"));
        SetDigital(1, d => d.Button3 = GetButton(snapshot, "Gear 3"));
        SetDigital(1, d => d.Button4 = GetButton(snapshot, "Gear 4"));
        SetDigital(1, d => d.Button5 = GetButton(snapshot, "Gear 5"));
        SetDigital(1, d => d.Button6 = GetButton(snapshot, "Gear 6"));

        JvsPackageEmulator.UpdateCoinCount(0);
    }

    private static bool GetButton(InputStateSnapshot snapshot, string action) => snapshot.Buttons.TryGetValue(action, out var pressed) && pressed;

    private static void SetDigital(int player, Action<PlayerButtons> setter) => setter(InputCode.PlayerDigitalButtons[player]);

    private static bool IsCenteredAction(string action) => action.Equals("Wheel Axis", StringComparison.OrdinalIgnoreCase);

    private static byte ToJvsCenteredByte(double normalized)
    {
        if (double.IsNaN(normalized)) normalized = 0;
        return (byte)Math.Clamp((int)Math.Round((Math.Clamp(normalized, -1, 1) + 1.0) * 127.5), 0, 255);
    }

    private static byte ToJvsPositiveByte(double normalized)
    {
        if (double.IsNaN(normalized)) normalized = 0;
        return (byte)Math.Clamp((int)Math.Round(Math.Clamp(normalized, 0, 1) * 255.0), 0, 255);
    }

    private static double NormalizeAxis(int raw, bool centered, bool invert, double deadzone)
    {
        double value;
        if (centered)
        {
            value = (raw - 32768.0) / 32767.0;
        }
        else
        {
            value = raw / 65535.0;
        }

        if (invert) value = centered ? -value : 1.0 - value;
        if (centered)
        {
            if (Math.Abs(value) < deadzone) value = 0;
            else value = Math.Sign(value) * ((Math.Abs(value) - deadzone) / Math.Max(0.0001, 1 - deadzone));
        }
        else if (value < deadzone)
        {
            value = 0;
        }
        else
        {
            value = (value - deadzone) / Math.Max(0.0001, 1 - deadzone);
        }
        return Math.Clamp(value, centered ? -1 : 0, 1);
    }

    private static double NormalizeXInputAxis(short raw, bool centered, bool invert, double deadzone)
    {
        if (!centered)
            return NormalizeAxis((raw + 32768) * 1, false, invert, deadzone);

        var value = Math.Clamp(raw / 32767.0, -1, 1);
        if (invert) value = -value;
        if (Math.Abs(value) < deadzone) value = 0;
        else value = Math.Sign(value) * ((Math.Abs(value) - deadzone) / Math.Max(0.0001, 1 - deadzone));
        return Math.Clamp(value, -1, 1);
    }

    private static int? GetDirectInputAxis(JoystickState state, string axis)
    {
        return axis switch
        {
            "X" => state.X,
            "Y" => state.Y,
            "Z" => state.Z,
            "Rotation X" => state.RotationX,
            "Rotation Y" => state.RotationY,
            "Rotation Z" => state.RotationZ,
            "Slider 1" => state.Sliders.Length > 0 ? state.Sliders[0] : null,
            "Slider 2" => state.Sliders.Length > 1 ? state.Sliders[1] : null,
            _ => null
        };
    }

    private static double? GetXInputAxisValue(Gamepad gamepad, string axis)
    {
        return axis switch
        {
            "Left Thumb X" => gamepad.LeftThumbX / 32767.0,
            "Left Thumb Y" => gamepad.LeftThumbY / 32767.0,
            "Right Thumb X" => gamepad.RightThumbX / 32767.0,
            "Right Thumb Y" => gamepad.RightThumbY / 32767.0,
            "Left Trigger" => gamepad.LeftTrigger / 255.0,
            "Right Trigger" => gamepad.RightTrigger / 255.0,
            _ => null
        };
    }

    private static double NormalizeXInputAxisValue(double raw, bool centered, bool invert, double deadzone)
    {
        var value = centered ? Math.Clamp(raw, -1, 1) : Math.Clamp(raw, 0, 1);
        if (invert) value = centered ? -value : 1 - value;
        if (centered)
        {
            if (Math.Abs(value) < deadzone) return 0;
            value = Math.Sign(value) * ((Math.Abs(value) - deadzone) / Math.Max(0.0001, 1 - deadzone));
        }
        else if (value < deadzone)
        {
            return 0;
        }
        else
        {
            value = (value - deadzone) / Math.Max(0.0001, 1 - deadzone);
        }
        return Math.Clamp(value, centered ? -1 : 0, 1);
    }

    private static bool GetXInputButton(GamepadButtonFlags flags, string input)
    {
        if (!Enum.TryParse<GamepadButtonFlags>(input, true, out var button))
            return false;
        return (flags & button) != 0;
    }

    private static bool PovPressed(int value, string input)
    {
        if (value < 0) return false;
        if (!int.TryParse(input, out var target)) return false;
        return Math.Abs(value - target) <= 450;
    }

    private static bool HasAnyBoundInputForDevice(IEnumerable<InputBinding> bindings) => bindings.Any();

    private void TryCapture()
    {
        string? action;
        TaskCompletionSource<InputBinding?>? completion;
        lock (_sync)
        {
            action = _captureAction;
            completion = _captureCompletion;
        }

        if (string.IsNullOrWhiteSpace(action) || completion is null)
            return;

        try
        {
            var binding = Api == InputApi.XInput ? CaptureXInput() : CaptureDirectInput();
            if (binding is not null)
            {
                binding.Api = Api.ToString();
                SetBinding(action, binding);
                Save();
            }
            completion.TrySetResult(binding);
        }
        catch (Exception ex)
        {
            Debug.WriteLine($"[Input] Capture error: {ex.Message}");
            completion.TrySetResult(null);
        }
        finally
        {
            lock (_sync)
            {
                _captureRequested = false;
                _captureAction = null;
                _captureCompletion = null;
            }
        }
    }

    private InputBinding? CaptureXInput()
    {
        var deadline = Environment.TickCount64 + 12000;
        var baseline = new Dictionary<int, State>();
        for (var i = 0; i < 4; i++)
        {
            var controller = new Controller((UserIndex)i);
            if (controller.IsConnected)
                baseline[i] = controller.GetState();
        }

        while (_running && Environment.TickCount64 < deadline)
        {
            for (var i = 0; i < 4; i++)
            {
                var controller = new Controller((UserIndex)i);
                if (!controller.IsConnected) continue;

                var state = controller.GetState();
                baseline.TryGetValue(i, out var old);
                var oldFlags = old.Gamepad.Buttons;
                var newFlags = state.Gamepad.Buttons;
                var pressed = newFlags & ~oldFlags;

                foreach (var flag in XInputCaptureButtons)
                {
                    if ((pressed & flag) != 0)
                        return new InputBinding { Kind = InputBindingKind.Button, DeviceIndex = i, Input = flag.ToString() };
                }

                if (Math.Abs(state.Gamepad.LeftThumbX - old.Gamepad.LeftThumbX) > 8000)
                    return new InputBinding { Kind = InputBindingKind.Axis, DeviceIndex = i, Input = "Left Thumb X" };
                if (Math.Abs(state.Gamepad.LeftThumbY - old.Gamepad.LeftThumbY) > 8000)
                    return new InputBinding { Kind = InputBindingKind.Axis, DeviceIndex = i, Input = "Left Thumb Y" };
                if (Math.Abs(state.Gamepad.RightThumbX - old.Gamepad.RightThumbX) > 8000)
                    return new InputBinding { Kind = InputBindingKind.Axis, DeviceIndex = i, Input = "Right Thumb X" };
                if (Math.Abs(state.Gamepad.RightThumbY - old.Gamepad.RightThumbY) > 8000)
                    return new InputBinding { Kind = InputBindingKind.Axis, DeviceIndex = i, Input = "Right Thumb Y" };
                if (Math.Abs(state.Gamepad.LeftTrigger - old.Gamepad.LeftTrigger) > 40)
                    return new InputBinding { Kind = InputBindingKind.Axis, DeviceIndex = i, Input = "Left Trigger" };
                if (Math.Abs(state.Gamepad.RightTrigger - old.Gamepad.RightTrigger) > 40)
                    return new InputBinding { Kind = InputBindingKind.Axis, DeviceIndex = i, Input = "Right Trigger" };

                baseline[i] = state;
            }
            Thread.Sleep(20);
        }
        return null;
    }

    private static readonly GamepadButtonFlags[] XInputCaptureButtons =
    {
        GamepadButtonFlags.A, GamepadButtonFlags.B, GamepadButtonFlags.X, GamepadButtonFlags.Y,
        GamepadButtonFlags.Back, GamepadButtonFlags.Start,
        GamepadButtonFlags.LeftShoulder, GamepadButtonFlags.RightShoulder,
        GamepadButtonFlags.LeftThumb, GamepadButtonFlags.RightThumb,
        GamepadButtonFlags.DPadUp, GamepadButtonFlags.DPadDown,
        GamepadButtonFlags.DPadLeft, GamepadButtonFlags.DPadRight
    };

    private InputBinding? CaptureDirectInput()
    {
        var deadline = Environment.TickCount64 + 12000;
        using var directInput = new DirectInput();
        var devices = directInput.GetDevices(DeviceClass.GameControl, DeviceEnumerationFlags.AttachedOnly);
        var sessions = new List<(Joystick Joystick, Guid Guid, JoystickState Baseline)>();

        try
        {
            foreach (var info in devices)
            {
                try
                {
                    var joystick = new Joystick(directInput, info.InstanceGuid);
                    joystick.SetCooperativeLevel(IntPtr.Zero, CooperativeLevel.NonExclusive | CooperativeLevel.Background);
                    joystick.Acquire();
                    joystick.Poll();
                    var baseline = joystick.GetCurrentState();
                    sessions.Add((joystick, info.InstanceGuid, baseline));
                }
                catch { }
            }

            while (_running && Environment.TickCount64 < deadline)
            {
                for (var s = 0; s < sessions.Count; s++)
                {
                    var session = sessions[s];
                    try
                    {
                        session.Joystick.Poll();
                        var state = session.Joystick.GetCurrentState();

                        for (var b = 0; b < state.Buttons.Length; b++)
                        {
                            var wasDown = session.Baseline.Buttons.Length > b && session.Baseline.Buttons[b];
                            if (state.Buttons[b] && !wasDown)
                                return new InputBinding
                                {
                                    Kind = InputBindingKind.Button,
                                    DeviceGuid = session.Guid.ToString(),
                                    Index = b,
                                    Input = $"Button {b + 1}"
                                };
                        }

                        foreach (var axis in DirectInputAxes)
                        {
                            var now = GetDirectInputAxis(state, axis);
                            var before = GetDirectInputAxis(session.Baseline, axis);
                            if (now.HasValue && before.HasValue && Math.Abs(now.Value - before.Value) > 6000)
                            {
                                return new InputBinding
                                {
                                    Kind = InputBindingKind.Axis,
                                    DeviceGuid = session.Guid.ToString(),
                                    Input = axis
                                };
                            }
                        }

                        var povNow = state.PointOfViewControllers.Length > 0 ? state.PointOfViewControllers[0] : -1;
                        var povBefore = session.Baseline.PointOfViewControllers.Length > 0 ? session.Baseline.PointOfViewControllers[0] : -1;
                        if (povNow >= 0 && povNow != povBefore)
                        {
                            return new InputBinding
                            {
                                Kind = InputBindingKind.Pov,
                                DeviceGuid = session.Guid.ToString(),
                                Index = 0,
                                Input = povNow.ToString()
                            };
                        }

                        sessions[s] = (session.Joystick, session.Guid, state);
                    }
                    catch { }
                }
                Thread.Sleep(20);
            }
            return null;
        }
        finally
        {
            foreach (var session in sessions)
            {
                try { session.Joystick.Unacquire(); } catch { }
                session.Joystick.Dispose();
            }
        }
    }

    private static readonly string[] DirectInputAxes =
    {
        "X", "Y", "Z", "Rotation X", "Rotation Y", "Rotation Z", "Slider 1", "Slider 2"
    };

    public void Dispose() => Stop();
}
