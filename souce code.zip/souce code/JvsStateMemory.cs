#nullable enable
namespace InitialD8Launcher;

// Deprecated compatibility shell. JvsHelper owns TeknoParrot_JvsState.
public sealed class JvsStateMemory : IDisposable
{
    private static readonly Lazy<JvsStateMemory> InstanceValue = new(() => new JvsStateMemory());
    public static JvsStateMemory Instance => InstanceValue.Value;
    private JvsStateMemory() { }
    public void EnsureCreated() { }
    public void Release() { }
    public void Dispose() { }
}
