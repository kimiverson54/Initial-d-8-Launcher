using System.Diagnostics;
using System.Linq;

namespace InitialD8Launcher;

public sealed class GameProcessManager
{
    public void CreateGameProcess(
        string loaderPath,
        string gamePath,
        string loaderCoreArgument,
        bool hideWindow,
        string workingDirectory,
        bool isTest = false,
        string testMenuParameter = "-t")
    {
        if (string.IsNullOrWhiteSpace(loaderPath))
            throw new ArgumentException("OpenParrotLoader.exe path is required.", nameof(loaderPath));
        if (string.IsNullOrWhiteSpace(gamePath))
            throw new ArgumentException("Game EXE path is required.", nameof(gamePath));

        var info = new ProcessStartInfo
        {
            FileName = loaderPath,
            WorkingDirectory = workingDirectory,
            UseShellExecute = false,
            CreateNoWindow = hideWindow,
            WindowStyle = hideWindow ? ProcessWindowStyle.Hidden : ProcessWindowStyle.Normal
        };

        // Current launcher convention: OpenParrotLoader.exe <core-dir> <game-exe> [game args].
        // TPUI's separate test mode adds the profile's TestMenuParameter (-t for ID8)
        // to the game argument string before launching the same loader.
        info.ArgumentList.Add(loaderCoreArgument);
        info.ArgumentList.Add(Path.GetFullPath(gamePath));
        if (isTest && !string.IsNullOrWhiteSpace(testMenuParameter))
            info.ArgumentList.Add(testMenuParameter);

        var existingPath = info.Environment.TryGetValue("PATH", out var envValue)
            ? envValue
            : string.Empty;

        info.Environment["PATH"] = string.Join(
            Path.PathSeparator,
            new[] { Path.GetDirectoryName(loaderPath)!, workingDirectory, existingPath }
                .Where(p => !string.IsNullOrWhiteSpace(p)));

        Debug.WriteLine($"[TP] Loader: {info.FileName}");
        Debug.WriteLine($"[TP] Args: {string.Join(" ", info.ArgumentList.Select(QuoteForDebug))}");
        Process.Start(info);
    }

    private static string QuoteForDebug(string value)
    {
        return value.Contains(' ') ? $"\"{value}\"" : value;
    }
}
