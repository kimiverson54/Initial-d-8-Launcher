#nullable enable
namespace InitialD8Launcher;

public enum JVSPacket : byte
{
    SYNC_CODE = 0xE0,
    OP_RESET = 0xF0,
    OP_ADDRESS = 0xF1
}

public enum JVSStatus : byte
{
    OK = 0x01,
    UNKNOWN = 0x02
}

public enum JVSReport : byte
{
    OK = 0x01
}
