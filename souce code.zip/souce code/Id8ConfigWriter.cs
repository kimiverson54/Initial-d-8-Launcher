namespace InitialD8Launcher;

public sealed class Id8ConfigWriter
{
    private readonly Id8Config _config;

    public Id8ConfigWriter(Id8Config config)
    {
        _config = config;
    }

    public string Write(string gameExePath)
    {
        if (string.IsNullOrWhiteSpace(gameExePath))
            throw new ArgumentException("Game EXE path is required.", nameof(gameExePath));

        var gameDir = Path.GetDirectoryName(gameExePath);
        if (string.IsNullOrWhiteSpace(gameDir))
            throw new InvalidOperationException("Could not determine the game EXE directory.");

        var iniPath = Path.Combine(gameDir, "teknoparrot.ini");
        var content = File.Exists(iniPath)
            ? File.ReadAllText(iniPath)
            : string.Empty;

        content = UpdateSectionValue(content, "General", "Input API", _config.InputAPI);
        content = UpdateSectionValue(content, "General", "Framelimiter", _config.Framelimiter);
        content = UpdateSectionValue(content, "General", "LinearFiltering", _config.LinearFiltering);
        content = UpdateSectionValue(content, "General", "Windowed", _config.Windowed);
        content = UpdateSectionValue(content, "General", "ResolutionWidth", _config.ResolutionWidth);
        content = UpdateSectionValue(content, "General", "ResolutionHeight", _config.ResolutionHeight);
        content = UpdateSectionValue(content, "General", "ResolutionMode", _config.ResolutionMode);
        content = UpdateSectionValue(content, "General", "RenderResolution", _config.RenderResolution);
        content = UpdateSectionValue(content, "Graphics", "GPU Fix", _config.GPUFix);

        if (string.IsNullOrWhiteSpace(content))
            content = BuildIniContent();

        if (!content.EndsWith(Environment.NewLine, StringComparison.Ordinal))
            content += Environment.NewLine;

        File.WriteAllText(iniPath, content);
        return iniPath;
    }

    public string BuildIniContent()
    {
        var lines = new List<string>
        {
            "[General]",
        };

        foreach (var entry in _config.GetGeneralEntries())
            lines.Add($"{entry.Key}={entry.Value}");

        lines.Add(string.Empty);
        lines.Add("[Graphics]");

        foreach (var entry in _config.GetGraphicsEntries())
            lines.Add($"{entry.Key}={entry.Value}");

        return string.Join(Environment.NewLine, lines) + Environment.NewLine;
    }

    private static string UpdateSectionValue(string content, string sectionName, string key, string value)
    {
        var lines = string.IsNullOrWhiteSpace(content)
            ? new List<string>()
            : content.Replace("\r\n", "\n").Split('\n').ToList();

        var output = new List<string>();
        var inTargetSection = false;
        var targetSectionFound = false;
        var sectionUpdated = false;

        foreach (var line in lines)
        {
            var trimmed = line.Trim();

            if (trimmed.StartsWith("[", StringComparison.Ordinal) && trimmed.EndsWith("]", StringComparison.Ordinal))
            {
                if (inTargetSection && !sectionUpdated)
                    output.Add($"{key}={value}");

                inTargetSection = string.Equals(trimmed[1..^1].Trim(), sectionName, StringComparison.OrdinalIgnoreCase);
                targetSectionFound |= inTargetSection;
                sectionUpdated = false;
                output.Add(line);
                continue;
            }

            if (inTargetSection)
            {
                var equalsIndex = line.IndexOf('=');
                if (equalsIndex >= 0)
                {
                    var currentKey = line[..equalsIndex].Trim();
                    if (string.Equals(currentKey, key, StringComparison.OrdinalIgnoreCase))
                    {
                        output.Add($"{key}={value}");
                        sectionUpdated = true;
                        continue;
                    }
                }
            }

            output.Add(line);
        }

        if (inTargetSection && !sectionUpdated)
            output.Add($"{key}={value}");

        if (!targetSectionFound)
        {
            if (output.Count > 0 && !string.IsNullOrWhiteSpace(output[^1]))
                output.Add(string.Empty);

            output.Add($"[{sectionName}]");
            output.Add($"{key}={value}");
        }

        return string.Join(Environment.NewLine, output);
    }

    public static Id8Config CreateDefault() => Id8Config.CreateDefault();
}
