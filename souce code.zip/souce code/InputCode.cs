#nullable enable
namespace InitialD8Launcher;

/// <summary>
/// Minimal compatibility model matching the members consumed by the
/// upstream TeknoParrot JVS package emulator. The actual controller reader
/// can populate these values later.
/// </summary>
public sealed class PlayerButtons
{
    public Guid JoystickGuid { get; set; }

    public bool? Up { get; set; }
    public bool? Down { get; set; }
    public bool? Left { get; set; }
    public bool? Right { get; set; }
    public bool? Button1 { get; set; }
    public bool? Button2 { get; set; }
    public bool? Button3 { get; set; }
    public bool? Button4 { get; set; }
    public bool? Button5 { get; set; }
    public bool? Button6 { get; set; }
    public bool? Start { get; set; }
    public bool? Service { get; set; }
    public bool? Test { get; set; }
    public bool? Coin { get; set; }
    public bool? ExtensionButton1 { get; set; }
    public bool? ExtensionButton2 { get; set; }
    public bool? ExtensionButton3 { get; set; }
    public bool? ExtensionButton4 { get; set; }
    public bool? ExtensionButton1_1 { get; set; }
    public bool? ExtensionButton1_2 { get; set; }
    public bool? ExtensionButton1_3 { get; set; }
    public bool? ExtensionButton1_4 { get; set; }
    public bool? ExtensionButton1_5 { get; set; }
    public bool? ExtensionButton1_6 { get; set; }
    public bool? ExtensionButton1_7 { get; set; }
    public bool? ExtensionButton1_8 { get; set; }
    public bool? ExtensionButton2_1 { get; set; }
    public bool? ExtensionButton2_2 { get; set; }
    public bool? ExtensionButton2_3 { get; set; }
    public bool? ExtensionButton2_4 { get; set; }
    public bool? ExtensionButton2_5 { get; set; }
    public bool? ExtensionButton2_6 { get; set; }
    public bool? ExtensionButton2_7 { get; set; }
    public bool? ExtensionButton2_8 { get; set; }
    public bool? RelativeUp { get; set; }
    public bool? RelativeDown { get; set; }
    public bool? RelativeLeft { get; set; }
    public bool? RelativeRight { get; set; }
    public bool? Card { get; set; }
    public bool? Card2 { get; set; }

    public bool UpPressed() => Up == true;
    public bool DownPressed() => Down == true;
    public bool LeftPressed() => Left == true;
    public bool RightPressed() => Right == true;
}

public static class InputCode
{
    public static EmulationProfile ButtonMode { get; set; } = EmulationProfile.SegaInitialD;
    public static GameProfile? GameProfile { get; set; }
    public static byte[] AnalogBytes { get; } = new byte[32];
    public static byte[] AnalogBytes2 { get; } = new byte[32];
    public static byte[] EncoderBytes { get; } = new byte[4];

    public static PlayerButtons[] PlayerDigitalButtons { get; } =
    {
        new PlayerButtons(),
        new PlayerButtons(),
        new PlayerButtons(),
        new PlayerButtons()
    };

    public static void SetAnalogByte(int index, byte? value, bool jvsTwo = false)
    {
        if (!value.HasValue || index < 0 || index >= 32)
            return;
        (jvsTwo ? AnalogBytes2 : AnalogBytes)[index] = value.Value;
    }

    public static void SetEncoderByte(int index, byte value)
    {
        if (index >= 0 && index < EncoderBytes.Length)
            EncoderBytes[index] = value;
    }
}
