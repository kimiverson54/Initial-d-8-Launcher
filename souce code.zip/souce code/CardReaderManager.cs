using System.Diagnostics;
using System.Linq;

namespace InitialD8Launcher;

/// <summary>
/// Starts the ID8 card-reader daemon the same way as the observed TeknoParrot
/// runtime: OpenParrotLoader -> picodaemon.exe.
/// </summary>
public static class CardReaderManager
{
    public static Process? Start(
        string loaderPath,
        string picodaemonPath,
        string loaderCoreArgument,
        bool hideWindow,
        string workingDirectory)
    {
        if (string.IsNullOrWhiteSpace(loaderPath))
            throw new ArgumentException("OpenParrotLoader.exe path is required.", nameof(loaderPath));
        if (string.IsNullOrWhiteSpace(picodaemonPath))
            throw new ArgumentException("picodaemon.exe path is required.", nameof(picodaemonPath));
        if (!File.Exists(loaderPath))
            throw new FileNotFoundException("OpenParrotLoader.exe was not found.", loaderPath);
        if (!File.Exists(picodaemonPath))
            throw new FileNotFoundException("picodaemon.exe was not found.", picodaemonPath);

        if (Process.GetProcessesByName("picodaemon").Any())
        {
            Debug.WriteLine("[CARD] picodaemon.exe is already running; reusing the existing instance.");
            return null;
        }

        var info = new ProcessStartInfo
        {
            FileName = loaderPath,
            WorkingDirectory = workingDirectory,
            UseShellExecute = false,
            CreateNoWindow = hideWindow,
            WindowStyle = hideWindow ? ProcessWindowStyle.Hidden : ProcessWindowStyle.Normal
        };

        // Matches the working runtime structure observed from TeknoParrot:
        // OpenParrotLoader.exe <TP core> <picodaemon.exe>
        info.ArgumentList.Add(loaderCoreArgument);
        info.ArgumentList.Add(Path.GetFullPath(picodaemonPath));

        var existingPath = info.Environment.TryGetValue("PATH", out var envValue)
            ? envValue
            : string.Empty;

        var pathParts = new[]
        {
            Path.GetDirectoryName(loaderPath),
            workingDirectory,
            Path.GetDirectoryName(picodaemonPath),
            existingPath
        }
        .Where(p => !string.IsNullOrWhiteSpace(p))
        .Cast<string>()
        .ToArray();

        info.Environment["PATH"] = string.Join(Path.PathSeparator, pathParts);

        Debug.WriteLine($"[CARD] Loader: {info.FileName}");
        Debug.WriteLine($"[CARD] Args: {string.Join(" ", info.ArgumentList.Select(QuoteForDebug))}");
        Debug.WriteLine($"[CARD] Target: {Path.GetFullPath(picodaemonPath)}");

        return Process.Start(info);
    }

    private static string QuoteForDebug(string value)
    {
        return value.Contains(' ') ? $"\"{value}\"" : value;
    }
}
