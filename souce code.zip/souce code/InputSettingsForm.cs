#nullable enable
namespace InitialD8Launcher;

public sealed class InputSettingsForm : Form
{
    private readonly InputManager _input = InputManager.Instance;
    private readonly ComboBox _apiBox = new();
    private readonly TableLayoutPanel _rows = new();
    private readonly Dictionary<string, Label> _valueLabels = new(StringComparer.OrdinalIgnoreCase);
    private readonly System.Windows.Forms.Timer _timer = new() { Interval = 50 };
    private readonly Label _captureStatus = new();
    private Label _liveValueLabel = new();

    public InputSettingsForm()
    {
        Text = "Initial D 8 - Input Settings";
        StartPosition = FormStartPosition.CenterParent;
        MinimumSize = new Size(760, 700);
        ClientSize = new Size(820, 820);
        BackColor = Color.FromArgb(12, 14, 18);
        AutoScaleMode = AutoScaleMode.Dpi;
        Font = new Font("Segoe UI", 9.5F);

        BuildUi();
        _input.Start();
        ApplyConfigToUi();
        _timer.Tick += (_, _) => RefreshTestValues();
        _timer.Start();
        FormClosed += (_, _) => _timer.Stop();
    }

    private void BuildUi()
    {
        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 4,
            Padding = new Padding(18),
            BackColor = BackColor
        };
        root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        root.RowStyles.Add(new RowStyle(SizeType.AutoSize));

        var title = new Label
        {
            Text = "Input Settings",
            AutoSize = true,
            Font = new Font("Segoe UI", 20F, FontStyle.Bold),
            ForeColor = Color.FromArgb(245, 248, 250),
            Margin = new Padding(0, 0, 0, 12)
        };

        var apiRow = new FlowLayoutPanel
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            WrapContents = false,
            BackColor = Color.FromArgb(17, 20, 25),
            Padding = new Padding(12),
            Margin = new Padding(0, 0, 0, 10)
        };
        var apiLabel = new Label
        {
            Text = "Input API",
            AutoSize = true,
            ForeColor = Color.FromArgb(190, 198, 208),
            Font = new Font("Segoe UI", 9F, FontStyle.Bold),
            Margin = new Padding(0, 6, 14, 0)
        };
        _apiBox.DropDownStyle = ComboBoxStyle.DropDownList;
        _apiBox.Items.AddRange(new object[] { "DirectInput", "XInput" });
        _apiBox.Width = 180;
        _apiBox.BackColor = Color.FromArgb(25, 30, 37);
        _apiBox.ForeColor = Color.FromArgb(238, 242, 246);
        _apiBox.FlatStyle = FlatStyle.Flat;
        _apiBox.SelectedIndexChanged += (_, _) =>
        {
            _input.Api = _apiBox.SelectedIndex == 1 ? InputApi.XInput : InputApi.DirectInput;
            _input.SaveNow();
        };
        apiRow.Controls.Add(apiLabel);
        apiRow.Controls.Add(_apiBox);

        var scroll = new Panel
        {
            Dock = DockStyle.Fill,
            AutoScroll = true,
            BackColor = Color.FromArgb(17, 20, 25),
            Padding = new Padding(12)
        };
        _rows.Dock = DockStyle.Top;
        _rows.AutoSize = true;
        _rows.ColumnCount = 3;
        _rows.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 31F));
        _rows.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 56F));
        _rows.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 122F));
        _rows.BackColor = Color.FromArgb(17, 20, 25);

        AddSection("Driving", new[] { "Wheel Axis", "Gas", "Brake", "Shift up", "Shift Down", "View Change" });
        AddSection("Gears", new[] { "Gear 1", "Gear 2", "Gear 3", "Gear 4", "Gear 5", "Gear 6" });
        AddSection("Menu", new[] { "Menu Up", "Menu Down", "Menu Left", "Menu Right" });
        AddSection("System", new[] { "Start", "Coin", "Service", "Test" });

        var note = new Label
        {
            Text = "Wheel Axis Left / Right share the same Wheel Axis binding, matching the Initial D profile.",
            AutoSize = true,
            MaximumSize = new Size(620, 0),
            ForeColor = Color.FromArgb(145, 153, 164),
            Margin = new Padding(0, 12, 0, 0)
        };
        _rows.Controls.Add(note, 0, _rows.RowCount);
        _rows.SetColumnSpan(note, 3);
        _rows.RowCount++;

        var testHeader = new Label
        {
            Text = "Live Input",
            AutoSize = true,
            ForeColor = Color.FromArgb(255, 90, 90),
            Font = new Font("Segoe UI", 9F, FontStyle.Bold),
            Margin = new Padding(0, 14, 0, 5)
        };
        _rows.Controls.Add(testHeader, 0, _rows.RowCount);
        _rows.SetColumnSpan(testHeader, 3);
        _rows.RowCount++;

        var live = new Label
        {
            Text = "Wheel Axis: 0.00\nGas: 0.00\nBrake: 0.00\nButtons: none",
            AutoSize = true,
            ForeColor = Color.FromArgb(190, 198, 208),
            BackColor = Color.FromArgb(25, 30, 37),
            Padding = new Padding(10),
            Margin = new Padding(0, 3, 0, 3)
        };
        _rows.Controls.Add(live, 0, _rows.RowCount);
        _rows.SetColumnSpan(live, 3);
        _rows.RowCount++;
        _liveValueLabel = live;

        scroll.Controls.Add(_rows);

        var bottom = new TableLayoutPanel
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            ColumnCount = 2,
            BackColor = Color.FromArgb(15, 17, 22),
            Padding = new Padding(12),
            Margin = new Padding(0, 10, 0, 0)
        };
        bottom.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        bottom.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));

        _captureStatus.Text = "Ready";
        _captureStatus.AutoSize = true;
        _captureStatus.ForeColor = Color.FromArgb(190, 198, 208);
        _captureStatus.Anchor = AnchorStyles.Left;

        var closeButton = new Button
        {
            Text = "CLOSE",
            Width = 100,
            Height = 38,
            BackColor = Color.FromArgb(39, 46, 56),
            ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat,
            Anchor = AnchorStyles.Right
        };
        closeButton.FlatAppearance.BorderSize = 0;
        closeButton.Click += (_, _) => Close();

        bottom.Controls.Add(_captureStatus, 0, 0);
        bottom.Controls.Add(closeButton, 1, 0);

        root.Controls.Add(title, 0, 0);
        root.Controls.Add(apiRow, 0, 1);
        root.Controls.Add(scroll, 0, 2);
        root.Controls.Add(bottom, 0, 3);

        Controls.Add(root);
    }

    private void AddSection(string title, IEnumerable<string> actions)
    {
        var section = new Label
        {
            Text = title,
            AutoSize = true,
            ForeColor = Color.FromArgb(255, 90, 90),
            Font = new Font("Segoe UI", 9F, FontStyle.Bold),
            Margin = new Padding(0, 12, 0, 5)
        };
        _rows.Controls.Add(section, 0, _rows.RowCount);
        _rows.SetColumnSpan(section, 3);
        _rows.RowCount++;

        foreach (var action in actions)
        {
            var label = new Label
            {
                Text = action,
                AutoSize = true,
                Anchor = AnchorStyles.Left,
                ForeColor = Color.FromArgb(220, 224, 228),
                Margin = new Padding(0, 7, 0, 7)
            };

            var value = new Label
            {
                Text = FormatBinding(_input.GetBinding(action)),
                AutoEllipsis = true,
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleLeft,
                ForeColor = Color.FromArgb(150, 160, 172),
                BackColor = Color.FromArgb(25, 30, 37),
                Padding = new Padding(8, 0, 8, 0),
                Margin = new Padding(0, 3, 8, 3)
            };

            var bindButton = new Button
            {
                Text = "BIND",
                Width = 70,
                Height = 32,
                BackColor = Color.FromArgb(214, 44, 44),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Margin = new Padding(0, 3, 0, 3)
            };
            bindButton.FlatAppearance.BorderSize = 0;

            bindButton.Click += async (_, _) =>
            {
                _captureStatus.Text = $"Waiting for input: {action}";
                bindButton.Enabled = false;
                try
                {
                    var binding = await _input.CaptureBindingAsync(action);
                    if (binding is null)
                        _captureStatus.Text = "No input detected (12 second timeout).";
                    else
                    {
                        value.Text = FormatBinding(binding);
                        _captureStatus.Text = $"Bound: {action} → {value.Text}";
                    }
                }
                finally
                {
                    bindButton.Enabled = true;
                }
            };

            var clearButton = new Button
            {
                Text = "CLEAR",
                Width = 46,
                Height = 32,
                BackColor = Color.FromArgb(45, 50, 58),
                ForeColor = Color.FromArgb(235, 238, 242),
                FlatStyle = FlatStyle.Flat,
                Margin = new Padding(6, 3, 0, 3)
            };
            clearButton.FlatAppearance.BorderSize = 0;
            clearButton.Click += (_, _) =>
            {
                _input.ClearBinding(action);
                _input.SaveNow();
                value.Text = "Unbound";
                _captureStatus.Text = $"Cleared: {action}";
            };

            var buttonPanel = new FlowLayoutPanel
            {
                AutoSize = false,
                Dock = DockStyle.Fill,
                WrapContents = false,
                FlowDirection = FlowDirection.LeftToRight,
                Margin = new Padding(0),
                Padding = new Padding(0)
            };
            buttonPanel.Controls.Add(bindButton);
            buttonPanel.Controls.Add(clearButton);

            _valueLabels[action] = value;
            _rows.Controls.Add(label, 0, _rows.RowCount);
            _rows.Controls.Add(value, 1, _rows.RowCount);
            _rows.Controls.Add(buttonPanel, 2, _rows.RowCount);
            _rows.RowCount++;
        }
    }

    private void ApplyConfigToUi()
    {
        _apiBox.SelectedIndex = _input.Api == InputApi.XInput ? 1 : 0;
        foreach (var pair in _valueLabels)
            pair.Value.Text = FormatBinding(_input.GetBinding(pair.Key));
    }

    private void RefreshTestValues()
    {
        var snapshot = _input.GetSnapshot();
        var pressed = snapshot.Buttons.Where(p => p.Value).Select(p => p.Key).ToArray();
        _liveValueLabel.Text = $"Wheel Axis: {snapshot.WheelAxis:+0.00;-0.00;0.00}\nGas: {snapshot.Gas:0.00}\nBrake: {snapshot.Brake:0.00}\nButtons: {(pressed.Length == 0 ? "none" : string.Join(", ", pressed))}";
    }

    private static string FormatBinding(InputBinding binding)
    {
        if (!binding.IsBound)
            return "Unbound";

        var device = binding.Api.Equals(nameof(InputApi.XInput), StringComparison.OrdinalIgnoreCase)
            ? $"XInput #{binding.DeviceIndex + 1}"
            : (string.IsNullOrWhiteSpace(binding.DeviceGuid) ? "DirectInput" : $"DI {binding.DeviceGuid[..Math.Min(8, binding.DeviceGuid.Length)]}");

        return binding.Kind switch
        {
            InputBindingKind.Button => $"{device} · {binding.Input}",
            InputBindingKind.Axis => $"{device} · {binding.Input}",
            InputBindingKind.Pov => $"{device} · POV {binding.Input}",
            _ => binding.Input
        };
    }
}
