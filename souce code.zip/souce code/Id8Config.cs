namespace InitialD8Launcher;

public sealed class Id8Config
{
    public string InputAPI { get; set; } = "DirectInput";
    public string DongleRegion { get; set; } = "JAPAN";
    public string PcbRegion { get; set; } = "JAPAN";
    public string Framelimiter { get; set; } = "1";
    public string LinearFiltering { get; set; } = "1";
    public string FreePlay { get; set; } = "1";
    public string Windowed { get; set; } = "1";
    public string ResolutionWidth { get; set; } = "1360";
    public string ResolutionHeight { get; set; } = "768";
    public string ResolutionMode { get; set; } = "Upscale";
    public string RenderResolution { get; set; } = "Auto";
    public string RealGearshift { get; set; } = "0";
    public string ID8TextGuard { get; set; } = "1";
    public string UseKeyboardButtonForAxis { get; set; } = "0";
    public string KeyboardButtonAxisWheelSensitivity { get; set; } = "10";
    public string KeyboardButtonAxisPedalSensitivity { get; set; } = "10";
    public string GPUFix { get; set; } = "None";

    public static Id8Config CreateDefault() => new();

    public static Id8Config FromIniFile(string iniPath)
    {
        var config = CreateDefault();
        if (!File.Exists(iniPath))
            return config;

        var currentSection = string.Empty;
        foreach (var rawLine in File.ReadAllLines(iniPath))
        {
            var line = rawLine.Trim();
            if (string.IsNullOrWhiteSpace(line) || line.StartsWith(";", StringComparison.Ordinal) || line.StartsWith("#", StringComparison.Ordinal))
                continue;

            if (line.StartsWith("[", StringComparison.Ordinal) && line.EndsWith("]", StringComparison.Ordinal))
            {
                currentSection = line[1..^1].Trim();
                continue;
            }

            var equalsIndex = line.IndexOf('=');
            if (equalsIndex < 0)
                continue;

            var key = line[..equalsIndex].Trim();
            var value = line[(equalsIndex + 1)..].Trim();

            if (string.Equals(currentSection, "General", StringComparison.OrdinalIgnoreCase))
            {
                ApplyGeneralValue(config, key, value);
            }
            else if (string.Equals(currentSection, "Graphics", StringComparison.OrdinalIgnoreCase))
            {
                ApplyGraphicsValue(config, key, value);
            }
        }

        return config;
    }

    public IReadOnlyList<KeyValuePair<string, string>> GetGeneralEntries()
    {
        return new[]
        {
            new KeyValuePair<string, string>("Input API", InputAPI),
            new KeyValuePair<string, string>(nameof(Framelimiter), Framelimiter),
            new KeyValuePair<string, string>(nameof(LinearFiltering), LinearFiltering),
            new KeyValuePair<string, string>(nameof(Windowed), Windowed),
            new KeyValuePair<string, string>(nameof(ResolutionWidth), ResolutionWidth),
            new KeyValuePair<string, string>(nameof(ResolutionHeight), ResolutionHeight),
            new KeyValuePair<string, string>(nameof(ResolutionMode), ResolutionMode),
            new KeyValuePair<string, string>(nameof(RenderResolution), RenderResolution),
        };
    }

    public IReadOnlyList<KeyValuePair<string, string>> GetGraphicsEntries()
    {
        return new[]
        {
            new KeyValuePair<string, string>("GPU Fix", GPUFix),
        };
    }

    private static void ApplyGeneralValue(Id8Config config, string key, string value)
    {
        switch (key)
        {
            case "Input API": config.InputAPI = value; break;
            case "Framelimiter": config.Framelimiter = value; break;
            case "LinearFiltering": config.LinearFiltering = value; break;
            case "Windowed": config.Windowed = value; break;
            case "ResolutionWidth": config.ResolutionWidth = value; break;
            case "ResolutionHeight": config.ResolutionHeight = value; break;
            case "ResolutionMode": config.ResolutionMode = value; break;
            case "RenderResolution": config.RenderResolution = value; break;
        }
    }

    private static void ApplyGraphicsValue(Id8Config config, string key, string value)
    {
        if (string.Equals(key, "GPU Fix", StringComparison.OrdinalIgnoreCase))
            config.GPUFix = value;
    }
}
