namespace InitialD8Launcher;

public sealed class GameProfile
{
    public string ProfileName { get; set; } = "InitialD8";
    public string GamePath { get; set; } = string.Empty;
    public string GamePath2 { get; set; } = string.Empty;
    public EmulationProfile EmulationProfile { get; set; } = EmulationProfile.SegaInitialD;
    public bool LaunchSecondExecutableFirst { get; set; }
    public string SecondExecutableArguments { get; set; } = string.Empty;
    public bool AllowSettingSync { get; set; }
}
