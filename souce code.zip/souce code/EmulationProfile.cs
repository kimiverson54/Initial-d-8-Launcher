namespace InitialD8Launcher;

public enum EmulationProfile
{
    SegaInitialD,
    SegaInitialDLindbergh
}
