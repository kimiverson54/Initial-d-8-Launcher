namespace InitialD8Launcher;

public static class JvsNeutralState
{
    public const byte WheelCenter = 0x80;
    public const byte GasNeutral = 0x00;
    public const byte BrakeNeutral = 0x00;
    public const byte ButtonReleased = 0x00;

    public static readonly byte[] DigitalButtons =
    {
        0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00
    };

    public static readonly byte[] AnalogChannels =
    {
        WheelCenter, 0x80,
        GasNeutral, 0x00,
        BrakeNeutral, 0x00,
        0x00, 0x00,
        0x00, 0x00,
        0x00, 0x00,
        0x00, 0x00,
        0x00, 0x00,
        0x00, 0x00
    };
}
