#nullable enable
using System.Text.Json.Serialization;

namespace InitialD8Launcher;

public enum InputApi
{
    DirectInput,
    XInput
}

public enum InputBindingKind
{
    Axis,
    Button,
    Pov
}

public sealed class InputBinding
{
    public string Api { get; set; } = nameof(InputApi.DirectInput);
    public string DeviceGuid { get; set; } = string.Empty;
    public int DeviceIndex { get; set; }
    public InputBindingKind Kind { get; set; }
    public string Input { get; set; } = string.Empty;
    public int Index { get; set; }
    public bool Negative { get; set; }
    public bool Invert { get; set; }
    public double Deadzone { get; set; } = 0.05;

    [JsonIgnore]
    public bool IsBound => !string.IsNullOrWhiteSpace(Input);

    public InputBinding Clone() => new()
    {
        Api = Api,
        DeviceGuid = DeviceGuid,
        DeviceIndex = DeviceIndex,
        Kind = Kind,
        Input = Input,
        Index = Index,
        Negative = Negative,
        Invert = Invert,
        Deadzone = Deadzone
    };
}
