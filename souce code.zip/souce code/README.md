# Initial D 8 Launcher

A lightweight Windows launcher for **Initial D Arcade Stage 8 Infinity**.

It starts a user-provided Initial D 8 dump by invoking the bundled OpenParrot
loader directly, so you do not have to install or open the TeknoParrot UI at all.

> **Goal: no TeknoParrot frontend required.** Pick your game, press one button,
> and the launcher wires up the JVS I/O emulation, the controller input, the
> graphics settings and the optional card reader for you.

- **Platform:** Windows (x64 host, x86 game core)
- **Runtime:** .NET 8 (`net8.0-windows`)
- **Version:** 0.7.5

---

## Table of contents

- [Features](#features)
- [Requirements](#requirements)
- [What this project does not include](#what-this-project-does-not-include)
- [Package layout](#package-layout)
- [Auto-detection](#auto-detection)
- [Launch flow](#launch-flow)
- [Graphics settings](#graphics-settings)
- [Input settings](#input-settings)
- [Card reader integration](#card-reader-integration)
- [Test mode](#test-mode)
- [Configuration and data files](#configuration-and-data-files)
- [Build](#build)
- [Publish as a single-file launcher](#publish-as-a-single-file-launcher)
- [Troubleshooting](#troubleshooting)
- [License](#license)
- [Third-party notices](#third-party-notices)

---

## Features

- **Direct launch** — calls `OpenParrotLoader.exe` with your Initial D 8
  executable; the TeknoParrot UI is never started.
- **Automatic detection** of the loader, the TeknoParrot core and the game EXE.
- **x86 core validation** — the launcher verifies that the selected
  `TeknoParrot.dll` is a 32-bit (x86) PE before launching, because ID8 uses the
  x86 core.
- **Graphics profile editing** — resolution, windowed mode, resolution mode,
  render resolution, linear filtering, framelimiter and GPU fix are read from and
  written to the game's `teknoparrot.ini`.
- **Controller input** — DirectInput (wheels, pedals, shifters, POV hats) and
  XInput (gamepads), with per-action binding, live input preview and deadzone
  handling. Wheel/gas/brake are translated into JVS analog values.
- **Built-in JVS emulation** — a named-pipe JVS server plus a JVS package
  emulator provide the I/O board the game expects, so no physical JVS hardware is
  needed.
- **Separate test mode** — a dedicated `TEST MODE` button starts the game with the
  `-t` test-menu parameter, independent of the physical JVS test switch.
- **Optional card reader** — starts `picodaemon.exe` through the same loader
  path, reusing an existing daemon if one is already running.
- **Debug toggles** — optionally show the OpenParrotLoader window and write a
  `jvs.log` next to the launcher for protocol-level diagnosis.

---

## Requirements

- **Windows 10 or later** (the launcher and OpenParrot runtime are Windows-only).
- **.NET 8 SDK** — only needed to build from source. Pre-built releases need the
  .NET 8 desktop runtime.
- **TeknoParrot core (`TeknoParrot.dll`, x86)** — provided by you.
- **OpenParrot runtime** — shipped with the project under `OpenParrotWin32/`.
- **Initial D 8 game files** — provided by you, placed under `rom/`.

---

## What this project does not include

To keep the repository redistributable, the following are **not** stored here and
must be supplied by the user:

- Initial D 8 game ROM / game files
- `TeknoParrot.dll` (the TeknoParrot core)
- `picodaemon.exe` (the card-reader daemon)

You must obtain these files yourself from a source you are legally allowed to use.

---

## Package layout

```text
InitialD8Launcher/
├─ InitialD8Launcher.exe
├─ TeknoParrot.dll                 ← provided by the user; not stored in the repo
├─ OpenParrotWin32/                ← OpenParrot open-source components shipped with the project
│  ├─ OpenParrotLoader.exe
│  └─ other official runtime files
└─ rom/
   └─ user-provided Initial D 8 game files
      └─ InitialD8_GLW_RE_SBZZ_dumped_.exe
```

The `runtime` folder is not used. The `TeknoParrot` folder is optional and is
only consulted as a preferred core argument for the card-reader loader.

---

## Auto-detection

The launcher looks for the following files next to itself, in the current working
directory, and then in up to six parent directories:

```text
.\TeknoParrot.dll
.\OpenParrotWin32\OpenParrotLoader.exe
.\rom\**\InitialD8*.exe
```

Any `*.exe` whose file name contains `InitialD8` is treated as a candidate game.
`InitialD8_GLW_RE_SBZZ_dumped_.exe` is preferred and sorted first when present.
If more than one candidate is found, pick the one you want from the drop-down.

---

## Launch flow

```text
InitialD8Launcher.exe
        ↓
OpenParrotWin32\OpenParrotLoader.exe
        ↓
TeknoParrot.dll
        ↓
InitialD8*.exe
```

The core argument automatically strips the `.dll` suffix so it matches the format
expected by `OpenParrotLoader`. Concretely, the launcher runs:

```text
OpenParrotWin32\OpenParrotLoader.exe .\TeknoParrot <game-exe> [game args]
```

The launcher also starts two background threads before launching:

- a **JVS pipe listener** on the named pipe `TeknoParrot_JVS`, and
- a **JVS queue processor** that decodes incoming packets and answers them via the
  JVS package emulator.

Input is polled continuously and written into the shared state that the emulator
reads, so the game receives wheel, pedal and button data as soon as it starts.

---

## Graphics settings

The graphics panel reads and writes the `teknoparrot.ini` located **next to the
selected game EXE**. Settings are applied when you press `LAUNCH GAME`.

| Setting           | Values                                        | INI key / section                     |
| ----------------- | --------------------------------------------- | ------------------------------------- |
| Resolution Width  | 640 – 3840                                    | `ResolutionWidth` (`[General]`)       |
| Resolution Height | 480 – 2160                                    | `ResolutionHeight` (`[General]`)      |
| Windowed          | `Windowed` / `Fullscreen`                     | `Windowed` (`[General]`)              |
| Resolution Mode   | `Upscale` / `Game`                            | `ResolutionMode` (`[General]`)        |
| Render Resolution | `Auto` / `Stock` / `1.5x` / `2x`              | `RenderResolution` (`[General]`)      |
| Linear Filtering  | on / off                                      | `LinearFiltering` (`[General]`)       |
| Framelimiter      | on / off                                      | `Framelimiter` (`[General]`)          |
| GPU Fix           | `None` / `AMD` / `New AMD Driver` / `INTEL`   | `GPU Fix` (`[Graphics]`)              |

Defaults are `1360 × 768`, windowed, `Upscale`, `Auto`, linear filtering on,
framelimiter on and GPU fix `None`. Existing keys are updated in place; missing
sections or keys are created.

---

## Input settings

Open `INPUT SETTINGS` to configure the controller. The dialog lists every action
and lets you `BIND` (press the control you want) or `CLEAR` each one. A live
preview shows the current wheel, gas and brake values and any pressed buttons.

**Supported APIs**

- **DirectInput** — wheels, pedals, shifters, POV hats. Axes: `X`, `Y`, `Z`,
  `Rotation X/Y/Z`, `Slider 1/2`. Buttons and POV directions are supported.
- **XInput** — Xbox-compatible gamepads (`XInput #1`–`#4`). Thumbsticks and
  triggers act as axes; the D-pad and face/shoulder buttons act as buttons.

**Bindable actions**

- Driving: `Wheel Axis`, `Gas`, `Brake`, `Shift up`, `Shift Down`, `View Change`
- Gears: `Gear 1` … `Gear 6`
- Menu: `Menu Up`, `Menu Down`, `Menu Left`, `Menu Right`
- System: `Start`, `Coin`, `Service`, `Test`

`Wheel Axis` is a centered (signed) axis; `Gas` and `Brake` are treated as
0–100% positive axes. Each binding stores an optional invert flag and a deadzone
(default `0.05`). Wheel, gas and brake are normalized and mapped to the JVS
analog channels (wheel → center `0x80`, gas/brake → `0x00` at rest).

---

## Card reader integration

When **Enable ID8 card reader** is checked (default), the launcher starts the card
daemon before the game:

```text
OpenParrotWin32\OpenParrotLoader.exe <core> <game-dir>\picodaemon.exe
```

- `picodaemon.exe` must sit **next to the selected ID8 EXE**.
- If a `picodaemon.exe` process is already running, the existing instance is
  reused instead of starting a second one.
- If `picodaemon.exe` is not found, the launcher continues and launches the game
  without the card reader.
- For the card loader, the launcher prefers the observed TPUI core argument
  `.\TeknoParrot\TeknoParrot` when that file exists, otherwise it falls back to
  `.\TeknoParrot`.

The card file lives at `%APPDATA%\TeknoParrot\SBZZ_card.bin`. See
[CARD_READER_SETUP.txt](CARD_READER_SETUP.txt) for the full test procedure.

---

## Test mode

The `TEST MODE` button follows TeknoParrotUI's separate-test-mode model for
Initial D:

- `LAUNCH GAME` runs the game normally (no extra argument).
- `TEST MODE` runs the same loader path with the game's `-t` test-menu parameter:

```text
OpenParrotWin32\OpenParrotLoader.exe .\TeknoParrot <game-exe> -t
```

This is separate from the physical JVS test switch and does not change the normal
launch path. See [TPUI_TESTMODE_NOTES.txt](TPUI_TESTMODE_NOTES.txt) for details.

---

## Configuration and data files

| File                                  | Purpose                                                        |
| ------------------------------------- | -------------------------------------------------------------- |
| `%APPDATA%\InitialD8Launcher\config.json` | Launcher preferences (card reader, debug window, cached paths) |
| `%APPDATA%\InitialD8Launcher\input.json`  | Controller API and per-action input bindings                   |
| `<game-dir>\teknoparrot.ini`          | Graphics settings for the selected game                        |
| `%APPDATA%\TeknoParrot\SBZZ_card.bin` | Active ID8 card file used by the card reader                   |
| `.\ID8_CARD\SBZZ_card.bin`            | Backup copy of the card, written when the launcher closes      |
| `.\jvs.log`                           | JVS protocol log (written next to the launcher)                |

The launcher also creates a 64-byte shared memory section named
`TeknoParrot_JvsState`, which is how input state is shared with the JVS emulator.

Paths are fixed relative to the launcher directory; only launcher preferences and
input bindings are stored in `%APPDATA%`.

---

## Build

Install the .NET 8 SDK, then from the repository root:

```powershell
dotnet build
dotnet run
```

Dependencies (restored automatically from NuGet):

- `System.IO.Ports` 8.0.0
- `SharpDX.DirectInput` 4.2.0
- `SharpDX.XInput` 4.2.0

---

## Publish as a single-file launcher

```powershell
dotnet publish -c Release -r win-x64 --self-contained true /p:PublishSingleFile=true /p:IncludeNativeLibrariesForSelfExtract=true
```

This publishes **your launcher** as a single EXE. `OpenParrotWin32`,
`TeknoParrot.dll`, and the `rom` directory remain as sidecar files and must stay
next to the published EXE.

---

## Troubleshooting

- **`LAUNCH GAME` is disabled.** One of the three required items is missing or
  invalid. Check the status lines under `OpenParrotLoader`, `TeknoParrot.dll` and
  the game list. The launcher requires an x86 `TeknoParrot.dll`.
- **"TeknoParrot.dll is not x86".** You selected a 64-bit core. ID8 needs the
  32-bit (x86) core.
- **No game found.** Make sure an `InitialD8*.exe` exists somewhere under `rom\`.
- **Game starts but inputs do nothing.** Open `INPUT SETTINGS` and confirm each
  action is bound and the live preview reacts. Verify `jvs.log` shows a client
  connecting on the `TeknoParrot_JVS` pipe.
- **Card Write/Save shows OFF.** Confirm `picodaemon.exe` is next to the game EXE
  and actually running, then inspect the Picodaemon-to-ID8 service state rather
  than the launcher input/JVS path.
- **Need loader output.** Enable **Show OpenParrotLoader window (debug)** and
  reproduce the launch.

---

## License

This project is licensed under the **GNU General Public License v3.0**
(GPL-3.0). See the full text in [LICENSE](LICENSE).

```
Initial D 8 Launcher
Copyright (C) 2026  Initial D 8 Launcher contributors

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
```

The GPL-3.0 choice is required in practice: this launcher contains adapted JVS
input/protocol logic and related implementation notes derived from the
GPL-3.0-licensed TeknoParrotUI ecosystem, and the bundled OpenParrot runtime is
also GPL-3.0 code. If you redistribute the launcher together with OpenParrot
binaries or derived source code, treat the GPL-3.0 terms as applying to that
redistributed bundle and keep the relevant notices attached — including
preserving copyright notices, the license text, and the source-availability
obligation.

---

## Third-party notices

See [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) for the full list. In short:

- **TeknoParrotUI** (GPL-3.0) — source of the adapted JVS protocol/transport and
  input-model code: <https://github.com/teknogods/TeknoParrotUI>
- **OpenParrot** (GPL-3.0) — the bundled runtime under `OpenParrotWin32/`
- **SharpDX.DirectInput** and **SharpDX.XInput** — NuGet packages used for
  controller access; see the license distributed with those packages.

Initial D and related trademarks are the property of their respective owners.
This project is not affiliated with or endorsed by SEGA.
