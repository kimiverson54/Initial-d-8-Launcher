namespace InitialD8Launcher;

public static class JvsConstants
{
    public const string PipeName = "TeknoParrot_JVS";
    public const string JvsStateMemoryName = "TeknoParrot_JvsState";
    public const int JvsStateMemorySize = 64;
    public const string SegaInitialDIdentifier = "SEGA CORPORATION;I/O BD JVS;837-14572;Ver1.00;2005/10\0";

    public const byte SyncCode = 0xE0;
    public const byte ResetCommand = 0xF0;
    public const byte AddressCommand = 0xF1;
    public const byte GetIdentifier = 0x10;
    public const byte GetCommandRevision = 0x11;
    public const byte GetJvsVersion = 0x12;
    public const byte GetCommunicationVersion = 0x13;
    public const byte GetSlaveFeatures = 0x14;
    public const byte ConveyMainBoardId = 0x15;
    public const byte GetDigital = 0x20;
    public const byte GetCoin = 0x21;
    public const byte GetAnalog = 0x22;
    public const byte GetMiscSwitch = 0x26;
    public const byte GeneralPurposeOutput = 0x32;
    public const byte StatusOk = 0x01;
    public const byte ReportOk = 0x01;
    public const byte NodeMaster = 0x00;
    public const byte Node1 = 0x01;
    public const byte Node2 = 0x02;
}
